package com.example.ui.admin

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.data.*
import com.example.ui.theme.*
import com.example.viewmodel.AdminViewModel

enum class AdminTab(val title: String, val icon: ImageVector) {
    DASHBOARD("Dashboard", Icons.Default.Dashboard),
    CATEGORIES("Categories", Icons.Default.Category),
    CHANNELS("Channels", Icons.Default.Tv),
    ADS("Ads", Icons.Default.Campaign),
    NOTICES("Notices", Icons.Default.NotificationImportant),
    SETTINGS("Settings", Icons.Default.Settings)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminMainScreen(
    viewModel: AdminViewModel,
    onBackToPlayer: () -> Unit
) {
    val isLoggedIn by viewModel.isLoggedIn.collectAsState()
    val successMessage by viewModel.successMessage.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(successMessage) {
        successMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessages()
        }
    }

    LaunchedEffect(errorMessage) {
        errorMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessages()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = DarkBackground
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            if (!isLoggedIn) {
                AdminLoginScreen(viewModel, onBackToPlayer)
            } else {
                AdminDashboardContent(viewModel)
            }

            if (isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.5f)),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = CyberBlue)
                }
            }
        }
    }
}

@Composable
fun AdminLoginScreen(
    viewModel: AdminViewModel,
    onBackToPlayer: () -> Unit
) {
    var email by remember { mutableStateOf("rsimam22@gmail.co") }
    var password by remember { mutableStateOf("b2Bfuck24@") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(DarkBackground, ImmersiveSecondary.copy(alpha = 0.3f))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .widthIn(max = 420.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Header Logo Icon
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(80.dp)
                    .background(CyberBlue, RoundedCornerShape(22.dp))
            ) {
                Icon(
                    imageVector = Icons.Default.Tv,
                    contentDescription = null,
                    tint = ImmersiveSecondary,
                    modifier = Modifier.size(44.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "IMU TV Admin Panel",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Connect securely to your Firebase systems",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Login fields Card
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = "Sign In",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White
                    )

                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Admin Email", color = TextSecondary) },
                        leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = CyberBlue) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = CyberBlue,
                            unfocusedBorderColor = Color.DarkGray,
                            focusedContainerColor = SurfaceLighter,
                            unfocusedContainerColor = SurfaceLighter
                        ),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("admin_email_input")
                    )

                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("Password", color = TextSecondary) },
                        leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = CyberBlue) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = CyberBlue,
                            unfocusedBorderColor = Color.DarkGray,
                            focusedContainerColor = SurfaceLighter,
                            unfocusedContainerColor = SurfaceLighter
                        ),
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("admin_password_input")
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = { viewModel.login(email, password) },
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CyberBlue,
                            contentColor = ImmersiveSecondary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("admin_login_submit")
                    ) {
                        Text(
                            text = "Login to Dashboard",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            TextButton(
                onClick = onBackToPlayer,
                colors = ButtonDefaults.textButtonColors(contentColor = CyberBlue)
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Return to Live Player")
            }
        }
    }
}

@Composable
fun AdminDashboardContent(viewModel: AdminViewModel) {
    var selectedTab by remember { mutableStateOf(AdminTab.DASHBOARD) }
    val isUploading by viewModel.isUploading.collectAsState()
    val uploadProgress by viewModel.uploadProgress.collectAsState()

    // Determine adaptive layout: Horizontal Navigation Rail for Expanded/Tablet width, Bottom Navigation for Compact/Phone.
    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWideScreen = maxWidth > 600.dp

        if (isWideScreen) {
            Row(modifier = Modifier.fillMaxSize()) {
                NavigationRail(
                    containerColor = SurfaceDark,
                    header = {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(vertical = 16.dp)
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(44.dp)
                                    .background(CyberBlue, RoundedCornerShape(10.dp))
                            ) {
                                Text("IMU", color = ImmersiveSecondary, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                ) {
                    AdminTab.values().forEach { tab ->
                        NavigationRailItem(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab },
                            icon = { Icon(tab.icon, contentDescription = tab.title) },
                            label = { Text(tab.title, fontSize = 11.sp) },
                            colors = NavigationRailItemDefaults.colors(
                                selectedIconColor = ImmersiveSecondary,
                                selectedTextColor = CyberBlue,
                                indicatorColor = CyberBlue,
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary
                            )
                        )
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    NavigationRailItem(
                        selected = false,
                        onClick = { viewModel.logout() },
                        icon = { Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = "Logout") },
                        label = { Text("Logout", fontSize = 11.sp) },
                        colors = NavigationRailItemDefaults.colors(
                            unselectedIconColor = NeonOrange,
                            unselectedTextColor = NeonOrange
                        )
                    )
                }

                VerticalDivider(color = Color.White.copy(alpha = 0.05f))

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                ) {
                    TabContent(selectedTab, viewModel)
                }
            }
        } else {
            // Mobile portrait: Bottom Navigation Bar + Content Panel
            Column(modifier = Modifier.fillMaxSize()) {
                Box(modifier = Modifier.weight(1f)) {
                    TabContent(selectedTab, viewModel)
                }

                NavigationBar(
                    containerColor = SurfaceDark,
                    tonalElevation = 8.dp
                ) {
                    AdminTab.values().forEach { tab ->
                        NavigationBarItem(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab },
                            icon = { Icon(tab.icon, contentDescription = tab.title) },
                            label = { Text(tab.title, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = ImmersiveSecondary,
                                selectedTextColor = CyberBlue,
                                indicatorColor = CyberBlue,
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary
                            )
                        )
                    }
                }
            }
        }

        // Upload progress overlay
        if (isUploading) {
            Dialog(onDismissRequest = {}) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                    modifier = Modifier.fillMaxWidth(0.85f)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(
                            progress = { (uploadProgress / 100f).toFloat() },
                            color = CyberBlue,
                            strokeWidth = 6.dp,
                            modifier = Modifier.size(72.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Uploading File...",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${uploadProgress.toInt()}% completed",
                            style = MaterialTheme.typography.bodyMedium,
                            color = CyberBlue
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TabContent(tab: AdminTab, viewModel: AdminViewModel) {
    Crossfade(
        targetState = tab,
        animationSpec = tween(300),
        label = "TabTransition"
    ) { currentTab ->
        when (currentTab) {
            AdminTab.DASHBOARD -> DashboardTabScreen(viewModel)
            AdminTab.CATEGORIES -> CategoriesTabScreen(viewModel)
            AdminTab.CHANNELS -> ChannelsTabScreen(viewModel)
            AdminTab.ADS -> AdsTabScreen(viewModel)
            AdminTab.NOTICES -> NoticesTabScreen(viewModel)
            AdminTab.SETTINGS -> SettingsTabScreen(viewModel)
        }
    }
}

// ==========================================
// 1. DASHBOARD TAB SCREEN
// ==========================================
@Composable
fun DashboardTabScreen(viewModel: AdminViewModel) {
    val categories by viewModel.categories.collectAsState()
    val channels by viewModel.channels.collectAsState()
    val ads by viewModel.ads.collectAsState()
    val notices by viewModel.notices.collectAsState()
    val userEmail by viewModel.userEmail.collectAsState()

    val totalCategories = categories.size
    val totalChannels = channels.size
    val totalNotices = notices.size
    val totalAds = ads.values.count { it.enabled }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp)
    ) {
        // Welcoming Banner
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Welcome back!",
                    style = MaterialTheme.typography.titleMedium,
                    color = TextSecondary
                )
                Text(
                    text = userEmail,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            IconButton(
                onClick = { viewModel.logout() },
                colors = IconButtonDefaults.iconButtonColors(containerColor = SurfaceLighter)
            ) {
                Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = "Logout", tint = NeonOrange)
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "System Statistics",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Grid of Stats
        BoxWithConstraints {
            val columns = if (maxWidth > 600.dp) GridCells.Fixed(4) else GridCells.Fixed(2)
            LazyVerticalGrid(
                columns = columns,
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 400.dp)
            ) {
                item {
                    StatCard(
                        title = "Categories",
                        count = totalCategories.toString(),
                        icon = Icons.Default.Category,
                        accentColor = CyberBlue
                    )
                }
                item {
                    StatCard(
                        title = "Live Channels",
                        count = totalChannels.toString(),
                        icon = Icons.Default.Tv,
                        accentColor = Color(0xFF00FFB2)
                    )
                }
                item {
                    StatCard(
                        title = "Active Ads",
                        count = totalAds.toString(),
                        icon = Icons.Default.Campaign,
                        accentColor = NeonOrange
                    )
                }
                item {
                    StatCard(
                        title = "Notices",
                        count = totalNotices.toString(),
                        icon = Icons.Default.NotificationImportant,
                        accentColor = Color(0xFFFFD000)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Quick System status summary
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(20.dp)
            ) {
                Text(
                    text = "System Integration Status",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(16.dp))

                StatusRow("Firebase Realtime Database", "Connected", Color.Green)
                Divider(color = Color.White.copy(alpha = 0.05f), modifier = Modifier.padding(vertical = 12.dp))
                StatusRow("Firebase Storage", "Connected", Color.Green)
                Divider(color = Color.White.copy(alpha = 0.05f), modifier = Modifier.padding(vertical = 12.dp))
                StatusRow("Active Streaming Protocol", "IPTV / HLS / M3U8", CyberBlue)
            }
        }
    }
}

@Composable
fun StatCard(
    title: String,
    count: String,
    icon: ImageVector,
    accentColor: Color
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(40.dp)
                        .background(accentColor.copy(alpha = 0.15f), CircleShape)
                ) {
                    Icon(icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(20.dp))
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = count,
                fontSize = 28.sp,
                fontWeight = FontWeight.Black,
                color = Color.White
            )

            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
fun StatusRow(label: String, value: String, statusColor: Color) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = TextSecondary, fontSize = 14.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(statusColor, CircleShape)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = value, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}


// ==========================================
// 2. CATEGORIES TAB SCREEN
// ==========================================
@Composable
fun CategoriesTabScreen(viewModel: AdminViewModel) {
    val categories by viewModel.categories.collectAsState()
    var categoryInput by remember { mutableStateOf("") }
    var editModeCat by remember { mutableStateOf<Category?>(null) }
    var showDeleteDialog by remember { mutableStateOf<Category?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
    ) {
        Text(
            text = "Category Management",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Spacer(modifier = Modifier.height(16.dp))

        // Create or Edit Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = if (editModeCat == null) "Create New Category" else "Edit Category",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = categoryInput,
                        onValueChange = { categoryInput = it },
                        placeholder = { Text("Category Name (e.g., Sports, News)", color = Color.Gray) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = CyberBlue,
                            unfocusedBorderColor = Color.DarkGray,
                            focusedContainerColor = SurfaceLighter,
                            unfocusedContainerColor = SurfaceLighter
                        ),
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("category_name_input")
                    )

                    Button(
                        onClick = {
                            val cat = editModeCat
                            if (cat == null) {
                                viewModel.addCategory(categoryInput)
                            } else {
                                viewModel.updateCategory(cat.id, categoryInput)
                                editModeCat = null
                            }
                            categoryInput = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberBlue, contentColor = ImmersiveSecondary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.height(54.dp)
                    ) {
                        Text(if (editModeCat == null) "Add" else "Update", fontWeight = FontWeight.Bold)
                    }

                    if (editModeCat != null) {
                        OutlinedButton(
                            onClick = {
                                editModeCat = null
                                categoryInput = ""
                            },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                            border = BorderStroke(1.dp, Color.DarkGray),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.height(54.dp)
                        ) {
                            Text("Cancel")
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "Available Categories (${categories.size})",
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Spacer(modifier = Modifier.height(12.dp))

        // Categories List
        LazyColumn(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(categories) { cat ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                    border = BorderStroke(0.5.dp, Color.White.copy(alpha = 0.05f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = cat.name,
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 16.sp,
                            modifier = Modifier.weight(1f)
                        )

                        Row {
                            IconButton(onClick = {
                                editModeCat = cat
                                categoryInput = cat.name
                            }) {
                                Icon(Icons.Default.Edit, contentDescription = "Edit", tint = CyberBlue)
                            }
                            IconButton(onClick = { showDeleteDialog = cat }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = NeonOrange)
                            }
                        }
                    }
                }
            }
        }
    }

    // Confirmation delete dialog
    showDeleteDialog?.let { cat ->
        AlertDialog(
            onDismissRequest = { showDeleteDialog = null },
            title = { Text("Delete Category", color = Color.White) },
            text = { Text("Are you sure you want to delete the category '${cat.name}'? This cannot be undone.", color = TextSecondary) },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteCategory(cat.id)
                        showDeleteDialog = null
                    }
                ) {
                    Text("Delete", color = NeonOrange, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = null }) {
                    Text("Cancel", color = Color.White)
                }
            },
            containerColor = SurfaceDark
        )
    }
}


// ==========================================
// 3. CHANNELS TAB SCREEN
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChannelsTabScreen(viewModel: AdminViewModel) {
    val channels by viewModel.channels.collectAsState()
    val categories by viewModel.categories.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var showFormDialog by remember { mutableStateOf<Channel?>(null) } // Non-null means form is open. Empty/null Channel means Add mode.
    var showDeleteDialog by remember { mutableStateOf<Channel?>(null) }

    val filteredChannels = channels.filter {
        it.name.contains(searchQuery, ignoreCase = true) ||
                it.category.contains(searchQuery, ignoreCase = true)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Channel Management",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            Button(
                onClick = { showFormDialog = Channel() }, // Trigger Empty Channel for Add Mode
                colors = ButtonDefaults.buttonColors(containerColor = CyberBlue, contentColor = ImmersiveSecondary),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Add Channel", fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Search bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search channels by name or category...", color = Color.Gray) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = CyberBlue) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                focusedBorderColor = CyberBlue,
                unfocusedBorderColor = Color.DarkGray,
                focusedContainerColor = SurfaceDark,
                unfocusedContainerColor = SurfaceDark
            ),
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("channel_search_bar")
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Channel list
        LazyColumn(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(filteredChannels) { ch ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                    border = BorderStroke(0.5.dp, Color.White.copy(alpha = 0.05f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Channel Logo
                        Box(
                            modifier = Modifier
                                .size(54.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(SurfaceLighter),
                            contentAlignment = Alignment.Center
                        ) {
                            if (ch.logoUrl.isNotEmpty()) {
                                AsyncImage(
                                    model = ch.logoUrl,
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                Icon(Icons.Default.Tv, contentDescription = null, tint = CyberBlue)
                            }
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        // Details
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = ch.name,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Box(
                                    modifier = Modifier
                                        .background(
                                            if (ch.active) Color.Green.copy(alpha = 0.15f) else Color.Red.copy(alpha = 0.15f),
                                            RoundedCornerShape(6.dp)
                                        )
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = if (ch.active) "ACTIVE" else "INACTIVE",
                                        color = if (ch.active) Color.Green else Color.Red,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = "Category: ${ch.category.uppercase()}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = CyberBlue
                            )

                            Spacer(modifier = Modifier.height(2.dp))

                            Text(
                                text = ch.streamUrl,
                                color = Color.Gray,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        Row {
                            IconButton(onClick = { showFormDialog = ch }) {
                                Icon(Icons.Default.Edit, contentDescription = "Edit", tint = CyberBlue)
                            }
                            IconButton(onClick = { showDeleteDialog = ch }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = NeonOrange)
                            }
                        }
                    }
                }
            }
        }
    }

    // Add or Edit Channel Form dialog
    showFormDialog?.let { ch ->
        var name by remember { mutableStateOf(ch.name) }
        var logoUrl by remember { mutableStateOf(ch.logoUrl) }
        var streamUrl by remember { mutableStateOf(ch.streamUrl) }
        var category by remember { mutableStateOf(ch.category.ifEmpty { if (categories.isNotEmpty()) categories[0].name else "" }) }
        var active by remember { mutableStateOf(ch.active) }

        var expandedCatDropdown by remember { mutableStateOf(false) }

        val imagePickerLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.GetContent()
        ) { uri: Uri? ->
            if (uri != null) {
                viewModel.uploadFile(uri, "logos", "${System.currentTimeMillis()}_logo.png") { downloadUrl ->
                    logoUrl = downloadUrl
                }
            }
        }

        AlertDialog(
            onDismissRequest = { showFormDialog = null },
            title = { Text(text = if (ch.id.isEmpty()) "Add Channel" else "Edit Channel", color = Color.White) },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Channel Name", color = TextSecondary) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = CyberBlue,
                            unfocusedBorderColor = Color.DarkGray,
                            focusedContainerColor = SurfaceLighter,
                            unfocusedContainerColor = SurfaceLighter
                        ),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Category Selector Dropdown
                    ExposedDropdownMenuBox(
                        expanded = expandedCatDropdown,
                        onExpandedChange = { expandedCatDropdown = !expandedCatDropdown }
                    ) {
                        OutlinedTextField(
                            value = category,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Category", color = TextSecondary) },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedCatDropdown) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = CyberBlue,
                                unfocusedBorderColor = Color.DarkGray,
                                focusedContainerColor = SurfaceLighter,
                                unfocusedContainerColor = SurfaceLighter
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = expandedCatDropdown,
                            onDismissRequest = { expandedCatDropdown = false },
                            modifier = Modifier.background(SurfaceDark)
                        ) {
                            categories.forEach { cat ->
                                DropdownMenuItem(
                                    text = { Text(cat.name, color = Color.White) },
                                    onClick = {
                                        category = cat.name
                                        expandedCatDropdown = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = streamUrl,
                        onValueChange = { streamUrl = it },
                        label = { Text("IPTV / Stream Link (HLS/M3U8)", color = TextSecondary) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = CyberBlue,
                            unfocusedBorderColor = Color.DarkGray,
                            focusedContainerColor = SurfaceLighter,
                            unfocusedContainerColor = SurfaceLighter
                        ),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Logo Selection Row
                    Text("Channel Logo", color = TextSecondary, fontSize = 12.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(54.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(SurfaceLighter),
                            contentAlignment = Alignment.Center
                        ) {
                            if (logoUrl.isNotEmpty()) {
                                AsyncImage(
                                    model = logoUrl,
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                Icon(Icons.Default.Image, contentDescription = null, tint = Color.Gray)
                            }
                        }

                        Button(
                            onClick = { imagePickerLauncher.launch("image/*") },
                            colors = ButtonDefaults.buttonColors(containerColor = SurfaceLighter, contentColor = Color.White),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.CloudUpload, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Upload Logo")
                        }
                    }

                    // Manual URL entry option
                    OutlinedTextField(
                        value = logoUrl,
                        onValueChange = { logoUrl = it },
                        label = { Text("Logo URL (Or Upload Above)", color = TextSecondary) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = CyberBlue,
                            unfocusedBorderColor = Color.DarkGray,
                            focusedContainerColor = SurfaceLighter,
                            unfocusedContainerColor = SurfaceLighter
                        ),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Active / Inactive Status
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Active Status", color = Color.White, fontWeight = FontWeight.Medium)
                        Switch(
                            checked = active,
                            onCheckedChange = { active = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = CyberBlue,
                                uncheckedThumbColor = Color.Gray,
                                uncheckedTrackColor = SurfaceLighter
                            )
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (ch.id.isEmpty()) {
                            viewModel.addChannel(name, logoUrl, streamUrl, category, active)
                        } else {
                            viewModel.updateChannel(ch.id, name, logoUrl, streamUrl, category, active)
                        }
                        showFormDialog = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberBlue, contentColor = ImmersiveSecondary)
                ) {
                    Text("Save", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showFormDialog = null }) {
                    Text("Cancel", color = Color.White)
                }
            },
            containerColor = SurfaceDark
        )
    }

    // Confirmation delete dialog
    showDeleteDialog?.let { ch ->
        AlertDialog(
            onDismissRequest = { showDeleteDialog = null },
            title = { Text("Delete Channel", color = Color.White) },
            text = { Text("Are you sure you want to delete the channel '${ch.name}'? This action cannot be reverted.", color = TextSecondary) },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteChannel(ch.id)
                        showDeleteDialog = null
                    }
                ) {
                    Text("Delete", color = NeonOrange, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = null }) {
                    Text("Cancel", color = Color.White)
                }
            },
            containerColor = SurfaceDark
        )
    }
}


// ==========================================
// 4. ADVERTISEMENT TAB SCREEN
// ==========================================
@Composable
fun AdsTabScreen(viewModel: AdminViewModel) {
    val ads by viewModel.ads.collectAsState()

    val clickAd = ads["click"] ?: Ad("click", "", false)
    val exitAd = ads["exit"] ?: Ad("exit", "", false)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        Text(
            text = "Advertisement Management",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )

        // 1. CLICK ADVERTISEMENT
        AdFormCard(
            title = "Channel Click Advertisement",
            subtitle = "Triggers when a viewer clicks on any IPTV live channel.",
            ad = clickAd,
            viewModel = viewModel
        )

        // 2. EXIT ADVERTISEMENT
        AdFormCard(
            title = "Exit Advertisement",
            subtitle = "Triggers when a viewer exits the video streaming screen.",
            ad = exitAd,
            viewModel = viewModel
        )
    }
}

@Composable
fun AdFormCard(
    title: String,
    subtitle: String,
    ad: Ad,
    viewModel: AdminViewModel
) {
    var videoUrl by remember(ad) { mutableStateOf(ad.videoUrl) }
    var enabled by remember(ad) { mutableStateOf(ad.enabled) }

    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.uploadFile(uri, "ads", "${System.currentTimeMillis()}_ad.mp4") { downloadUrl ->
                videoUrl = downloadUrl
            }
        }
    }

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = subtitle,
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                }

                Switch(
                    checked = enabled,
                    onCheckedChange = { enabled = it },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = CyberBlue,
                        uncheckedThumbColor = Color.Gray,
                        uncheckedTrackColor = SurfaceLighter
                    )
                )
            }

            Divider(color = Color.White.copy(alpha = 0.05f))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Video Advertisement Upload", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Medium)

                Button(
                    onClick = { videoPickerLauncher.launch("video/*") },
                    colors = ButtonDefaults.buttonColors(containerColor = SurfaceLighter, contentColor = Color.White),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.CloudUpload, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Pick & Upload Video File to Storage")
                }
            }

            OutlinedTextField(
                value = videoUrl,
                onValueChange = { videoUrl = it },
                label = { Text("Video URL (Or auto-filled from upload)", color = TextSecondary) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedBorderColor = CyberBlue,
                    unfocusedBorderColor = Color.DarkGray,
                    focusedContainerColor = SurfaceLighter,
                    unfocusedContainerColor = SurfaceLighter
                ),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = { viewModel.saveAd(ad.id, videoUrl, enabled) },
                colors = ButtonDefaults.buttonColors(containerColor = CyberBlue, contentColor = ImmersiveSecondary),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) {
                Text("Save Changes", fontWeight = FontWeight.Bold)
            }
        }
    }
}


// ==========================================
// 5. NOTICE TAB SCREEN
// ==========================================
@Composable
fun NoticesTabScreen(viewModel: AdminViewModel) {
    val notices by viewModel.notices.collectAsState()
    var noticeInput by remember { mutableStateOf("") }
    var noticeActive by remember { mutableStateOf(true) }
    var editModeNotice by remember { mutableStateOf<NoticeItem?>(null) }
    var showDeleteDialog by remember { mutableStateOf<NoticeItem?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
    ) {
        Text(
            text = "Notice Management",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Spacer(modifier = Modifier.height(16.dp))

        // Create or Edit Notice Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = if (editModeNotice == null) "Create Public Notice" else "Edit Notice",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                OutlinedTextField(
                    value = noticeInput,
                    onValueChange = { noticeInput = it },
                    placeholder = { Text("Type notice message (will crawl/marquee on home screen of player)", color = Color.Gray) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = CyberBlue,
                        unfocusedBorderColor = Color.DarkGray,
                        focusedContainerColor = SurfaceLighter,
                        unfocusedContainerColor = SurfaceLighter
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = noticeActive,
                            onCheckedChange = { noticeActive = it },
                            colors = CheckboxDefaults.colors(checkedColor = CyberBlue, checkmarkColor = ImmersiveSecondary)
                        )
                        Text("Active (Show immediately on live player)", color = Color.White, fontSize = 13.sp)
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (editModeNotice != null) {
                            OutlinedButton(
                                onClick = {
                                    editModeNotice = null
                                    noticeInput = ""
                                    noticeActive = true
                                },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                border = BorderStroke(1.dp, Color.DarkGray),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("Cancel")
                            }
                        }

                        Button(
                            onClick = {
                                val item = editModeNotice
                                if (item == null) {
                                    viewModel.addNotice(noticeInput, noticeActive)
                                } else {
                                    viewModel.updateNotice(item.id, noticeInput, noticeActive)
                                    editModeNotice = null
                                }
                                noticeInput = ""
                                noticeActive = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberBlue, contentColor = ImmersiveSecondary),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(if (editModeNotice == null) "Publish" else "Save", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "Active & Inactive Notices (${notices.size})",
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Spacer(modifier = Modifier.height(12.dp))

        // Notices List
        LazyColumn(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(notices) { notice ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                    border = BorderStroke(0.5.dp, Color.White.copy(alpha = 0.05f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Box(
                                modifier = Modifier
                                    .background(
                                        if (notice.active) Color.Green.copy(alpha = 0.15f) else Color.Red.copy(alpha = 0.15f),
                                        RoundedCornerShape(6.dp)
                                    )
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = if (notice.active) "ACTIVE" else "INACTIVE",
                                    color = if (notice.active) Color.Green else Color.Red,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Row {
                                IconButton(onClick = {
                                    editModeNotice = notice
                                    noticeInput = notice.text
                                    noticeActive = notice.active
                                }) {
                                    Icon(Icons.Default.Edit, contentDescription = "Edit", tint = CyberBlue)
                                }
                                IconButton(onClick = { showDeleteDialog = notice }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = NeonOrange)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = notice.text,
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }
    }

    // Confirmation delete dialog
    showDeleteDialog?.let { item ->
        AlertDialog(
            onDismissRequest = { showDeleteDialog = null },
            title = { Text("Delete Notice", color = Color.White) },
            text = { Text("Are you sure you want to delete this notice? This action cannot be undone.", color = TextSecondary) },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteNotice(item.id)
                        showDeleteDialog = null
                    }
                ) {
                    Text("Delete", color = NeonOrange, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = null }) {
                    Text("Cancel", color = Color.White)
                }
            },
            containerColor = SurfaceDark
        )
    }
}


// ==========================================
// 6. SETTINGS TAB SCREEN
// ==========================================
@Composable
fun SettingsTabScreen(viewModel: AdminViewModel) {
    val settings by viewModel.settings.collectAsState()

    var appName by remember(settings) { mutableStateOf(settings.appName) }
    var footerText by remember(settings) { mutableStateOf(settings.footerText) }
    var telegramLink by remember(settings) { mutableStateOf(settings.telegramLink) }
    var shareLink by remember(settings) { mutableStateOf(settings.shareLink) }
    var privacyPolicy by remember(settings) { mutableStateOf(settings.privacyPolicy) }
    var termsConditions by remember(settings) { mutableStateOf(settings.termsConditions) }
    var appLogoUrl by remember(settings) { mutableStateOf(settings.appLogoUrl) }

    val logoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.uploadFile(uri, "app_assets", "app_logo.png") { downloadUrl ->
                appLogoUrl = downloadUrl
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Text(
            text = "Global App Settings",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )

        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "App Identity & Customization",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Divider(color = Color.White.copy(alpha = 0.05f))

                // App Logo Picker Row
                Text("App Logo Asset", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(SurfaceLighter),
                        contentAlignment = Alignment.Center
                    ) {
                        if (appLogoUrl.isNotEmpty()) {
                            AsyncImage(
                                model = appLogoUrl,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Icon(Icons.Default.Tv, contentDescription = null, tint = CyberBlue, modifier = Modifier.size(36.dp))
                        }
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Button(
                            onClick = { logoPickerLauncher.launch("image/*") },
                            colors = ButtonDefaults.buttonColors(containerColor = SurfaceLighter, contentColor = Color.White),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.CloudUpload, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Upload App Logo")
                        }
                    }
                }

                OutlinedTextField(
                    value = appLogoUrl,
                    onValueChange = { appLogoUrl = it },
                    label = { Text("App Logo URL", color = TextSecondary) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = CyberBlue,
                        unfocusedBorderColor = Color.DarkGray,
                        focusedContainerColor = SurfaceLighter,
                        unfocusedContainerColor = SurfaceLighter
                    ),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = appName,
                    onValueChange = { appName = it },
                    label = { Text("Player App Name", color = TextSecondary) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = CyberBlue,
                        unfocusedBorderColor = Color.DarkGray,
                        focusedContainerColor = SurfaceLighter,
                        unfocusedContainerColor = SurfaceLighter
                    ),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = footerText,
                    onValueChange = { footerText = it },
                    label = { Text("Footer Copyright Text", color = TextSecondary) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = CyberBlue,
                        unfocusedBorderColor = Color.DarkGray,
                        focusedContainerColor = SurfaceLighter,
                        unfocusedContainerColor = SurfaceLighter
                    ),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = telegramLink,
                    onValueChange = { telegramLink = it },
                    label = { Text("Telegram Link", color = TextSecondary) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = CyberBlue,
                        unfocusedBorderColor = Color.DarkGray,
                        focusedContainerColor = SurfaceLighter,
                        unfocusedContainerColor = SurfaceLighter
                    ),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = shareLink,
                    onValueChange = { shareLink = it },
                    label = { Text("Share Link (Google Play Store)", color = TextSecondary) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = CyberBlue,
                        unfocusedBorderColor = Color.DarkGray,
                        focusedContainerColor = SurfaceLighter,
                        unfocusedContainerColor = SurfaceLighter
                    ),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = privacyPolicy,
                    onValueChange = { privacyPolicy = it },
                    label = { Text("Privacy Policy Content", color = TextSecondary) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = CyberBlue,
                        unfocusedBorderColor = Color.DarkGray,
                        focusedContainerColor = SurfaceLighter,
                        unfocusedContainerColor = SurfaceLighter
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp)
                )

                OutlinedTextField(
                    value = termsConditions,
                    onValueChange = { termsConditions = it },
                    label = { Text("Terms & Conditions Content", color = TextSecondary) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = CyberBlue,
                        unfocusedBorderColor = Color.DarkGray,
                        focusedContainerColor = SurfaceLighter,
                        unfocusedContainerColor = SurfaceLighter
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp)
                )

                Button(
                    onClick = {
                        viewModel.saveSettings(
                            appName,
                            footerText,
                            telegramLink,
                            shareLink,
                            privacyPolicy,
                            termsConditions,
                            appLogoUrl
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberBlue, contentColor = ImmersiveSecondary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                ) {
                    Text("Save Global Settings", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
