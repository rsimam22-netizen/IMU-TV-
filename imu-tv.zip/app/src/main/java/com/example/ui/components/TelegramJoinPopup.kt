package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.TelegramBlueEnd
import com.example.ui.theme.TelegramBlueStart

@Composable
fun TelegramJoinPopup(
    telegramLink: String,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = false
        )
    ) {
        var animateIn by remember { mutableStateOf(false) }
        
        LaunchedEffect(Unit) {
            animateIn = true
        }
        
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.75f))
                .clickable(enabled = false) {},
            contentAlignment = Alignment.Center
        ) {
            AnimatedVisibility(
                visible = animateIn,
                enter = fadeIn(animationSpec = tween(300)) + scaleIn(initialScale = 0.8f, animationSpec = tween(300)),
                exit = fadeOut(animationSpec = tween(250)) + scaleOut(targetScale = 0.8f, animationSpec = tween(250))
            ) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth(0.9f)
                        .wrapContentHeight()
                        .padding(16.dp),
                    shape = RoundedCornerShape(20.dp),
                    color = Color(0xFF1E1E24),
                    border = BorderStroke(1.dp, Color(0xFF33323B)),
                    tonalElevation = 8.dp
                ) {
                    Box(modifier = Modifier.padding(24.dp)) {
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .size(32.dp)
                                .background(Color(0x33FFFFFF), CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Spacer(modifier = Modifier.height(8.dp))
                            
                            Box(
                                modifier = Modifier
                                    .size(80.dp)
                                    .background(
                                        brush = Brush.verticalGradient(
                                            colors = listOf(TelegramBlueEnd, TelegramBlueStart)
                                        ),
                                        shape = CircleShape
                                    )
                                    .padding(4.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Canvas(modifier = Modifier.fillMaxSize()) {
                                    val px = size.width
                                    val py = size.height
                                    
                                    val mainPath = Path().apply {
                                        moveTo(px * 0.73f, py * 0.27f)
                                        lineTo(px * 0.24f, py * 0.50f)
                                        lineTo(px * 0.44f, py * 0.58f)
                                        lineTo(px * 0.48f, py * 0.75f)
                                        lineTo(px * 0.55f, py * 0.64f)
                                        lineTo(px * 0.73f, py * 0.27f)
                                    }
                                    drawPath(path = mainPath, color = Color.White)
                                    
                                    val foldPath = Path().apply {
                                        moveTo(px * 0.44f, py * 0.58f)
                                        lineTo(px * 0.48f, py * 0.75f)
                                        lineTo(px * 0.55f, py * 0.64f)
                                        close()
                                    }
                                    drawPath(path = foldPath, color = Color(0x22000000))
                                }
                            }
                            
                            Spacer(modifier = Modifier.height(16.dp))
                            
                            Text(
                                text = "JOIN IMU TV",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                letterSpacing = 1.sp,
                                textAlign = TextAlign.Center
                            )
                            
                            Spacer(modifier = Modifier.height(8.dp))
                            
                            Text(
                                text = "Get latest IPTV links, live sports updates, channel updates and important announcements instantly.",
                                fontSize = 14.sp,
                                color = Color.LightGray,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(horizontal = 8.dp),
                                lineHeight = 20.sp
                            )
                            
                            Spacer(modifier = Modifier.height(24.dp))
                            
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    FeatureCard(
                                        icon = "⚡",
                                        title = "Instant Channel Updates",
                                        modifier = Modifier.weight(1f)
                                    )
                                    FeatureCard(
                                        icon = "📺",
                                        title = "Latest IPTV Links",
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    FeatureCard(
                                        icon = "🔔",
                                        title = "Push Notifications",
                                        modifier = Modifier.weight(1f)
                                    )
                                    FeatureCard(
                                        icon = "👥",
                                        title = "Join Our Community",
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                            
                            Spacer(modifier = Modifier.height(28.dp))
                            
                            Button(
                                onClick = {
                                    openTelegramChannel(context, telegramLink)
                                    onDismiss()
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF229ED9),
                                    contentColor = Color.White
                                )
                            ) {
                                Text(
                                    text = "JOIN CHANNEL FREE",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp
                                )
                            }
                            
                            Spacer(modifier = Modifier.height(10.dp))
                            
                            TextButton(
                                onClick = onDismiss,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(44.dp)
                            ) {
                                Text(
                                    text = "Maybe Later",
                                    fontSize = 14.sp,
                                    color = Color.Gray,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FeatureCard(
    icon: String,
    title: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFF26252F),
        border = BorderStroke(1.dp, Color(0xFF33323D))
    ) {
        Column(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = icon,
                fontSize = 20.sp,
                modifier = Modifier.padding(bottom = 6.dp)
            )
            Text(
                text = title,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.White,
                textAlign = TextAlign.Center,
                lineHeight = 16.sp
            )
        }
    }
}

private fun openTelegramChannel(context: Context, link: String) {
    val cleanLink = if (link.isBlank()) "https://t.me/imustvsports" else link
    val uri = Uri.parse(cleanLink)
    val intent = Intent(Intent.ACTION_VIEW, uri)
    
    intent.setPackage("org.telegram.messenger")
    
    try {
        context.startActivity(intent)
    } catch (e: Exception) {
        intent.setPackage(null)
        try {
            context.startActivity(intent)
        } catch (e2: Exception) {
            Log.e("TelegramPopup", "Failed to open link: ${e2.message}")
        }
    }
}
