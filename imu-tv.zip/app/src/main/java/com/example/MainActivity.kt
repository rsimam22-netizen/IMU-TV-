package com.example

import android.app.Activity
import android.content.Intent
import android.content.res.Configuration
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.Channel
import com.example.data.Notice
import com.example.data.AppSettings
import com.example.ui.components.IPTVPlayer
import com.example.ui.components.VideoAdPlayer
import com.example.ui.components.TelegramJoinPopup
import com.example.ui.theme.*
import com.example.viewmodel.IPTVViewModel
import kotlinx.coroutines.delay
import android.content.Context

class MainActivity : ComponentActivity() {

    private val viewModel: IPTVViewModel by viewModels()
    private var isPipModeActive by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                var currentScreen by remember { mutableStateOf("splash") }

                if (currentScreen == "splash") {
                    SplashScreen(
                        onFinished = {
                            currentScreen = "home"
                        }
                    )
                } else {
                    MainApp(
                        viewModel = viewModel,
                        isPipActive = isPipModeActive,
                        onExitActivity = { finish() }
                    )
                }
            }
        }
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        isPipModeActive = isInPictureInPictureMode
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        // Automatically enter PiP mode if a channel is active and playing
        if (viewModel.activeStreamChannel.value != null) {
            try {
                enterPictureInPictureMode()
            } catch (e: Exception) {
                // PiP not supported or failed
            }
        }
    }
}

@Composable
fun SplashScreen(onFinished: () -> Unit) {
    val scale = remember { Animatable(0.5f) }
    val alpha = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        // Parallel animation
        animateToSplash(scale, alpha)
        delay(1000) // extra showcase delay
        onFinished()
    }

    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground) // Immersive background
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(24.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.imu_tv_logo),
                contentDescription = "IMU TV Logo",
                modifier = Modifier
                    .size(160.dp)
                    .scale(scale.value)
                    .alpha(alpha.value)
                    .clip(RoundedCornerShape(24.dp))
            )

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "IMU TV",
                style = MaterialTheme.typography.displayMedium,
                fontWeight = FontWeight.Black,
                color = Color.White,
                modifier = Modifier.alpha(alpha.value)
            )

            Text(
                text = "Premium Live IPTV Player",
                style = MaterialTheme.typography.titleMedium,
                color = CyberBlue, // Immersive Lavender accent
                modifier = Modifier.alpha(alpha.value),
                fontWeight = FontWeight.SemiBold
            )

            Spacer(modifier = Modifier.height(48.dp))

            CircularProgressIndicator(
                color = Color(0xFFFF5A14),
                modifier = Modifier
                    .size(40.dp)
                    .alpha(alpha.value)
            )
        }
    }
}

private suspend fun animateToSplash(scale: Animatable<Float, *>, alpha: Animatable<Float, *>) {
    scale.animateTo(
        targetValue = 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        )
    )
    alpha.animateTo(
        targetValue = 1f,
        animationSpec = tween(1200, easing = LinearOutSlowInEasing)
    )
}

@Composable
fun MainApp(
    viewModel: IPTVViewModel,
    isPipActive: Boolean,
    onExitActivity: () -> Unit
) {
    val context = LocalContext.current
    val isLoading by viewModel.isLoading.collectAsState()
    val isRefreshing by viewModel.isRefreshing.collectAsState()

    val channels by viewModel.channels.collectAsState()
    val categories by viewModel.categories.collectAsState()
    val notice by viewModel.notice.collectAsState()
    val adConfig by viewModel.adConfig.collectAsState()

    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val favoriteIds by viewModel.favoriteIds.collectAsState()
    val favoriteChannels by viewModel.favoriteChannels.collectAsState()

    val activeVideoAdChannel by viewModel.activeVideoAdChannel.collectAsState()
    val adTimeRemaining by viewModel.adTimeRemaining.collectAsState()
    val activeStreamChannel by viewModel.activeStreamChannel.collectAsState()

    val showExitAd by viewModel.showExitAd.collectAsState()
    val exitAdTimeRemaining by viewModel.exitAdTimeRemaining.collectAsState()

    val appSettings by viewModel.appSettings.collectAsState()
    var showTelegramPopup by remember { mutableStateOf(false) }

    LaunchedEffect(appSettings) {
        val prefs = context.getSharedPreferences("imu_tv_prefs", Context.MODE_PRIVATE)
        val lastShown = prefs.getLong("telegram_popup_last_shown", 0L)
        val currentTime = System.currentTimeMillis()
        val oneDayMillis = 24 * 60 * 60 * 1000L

        if (appSettings.telegramPopupEnabled && (lastShown == 0L || (currentTime - lastShown) >= oneDayMillis)) {
            delay(1500)
            showTelegramPopup = true
            prefs.edit().putLong("telegram_popup_last_shown", currentTime).apply()
        }
    }

    var showSearchRow by remember { mutableStateOf(false) }
    var showOnlyFavoritesMode by remember { mutableStateOf(false) }

    // Dialog state for Privacy & Terms
    var dialogTitle by remember { mutableStateOf("") }
    var dialogBody by remember { mutableStateOf("") }
    var showInfoDialog by remember { mutableStateOf(false) }

    // Intercept Back button
    BackHandler {
        if (activeStreamChannel != null || activeVideoAdChannel != null) {
            viewModel.closePlayer()
        } else {
            viewModel.triggerExitAd {
                onExitActivity()
            }
        }
    }

    // Filter Logic
    val filteredChannels = remember(channels, searchQuery, selectedCategory, showOnlyFavoritesMode, favoriteIds, favoriteChannels) {
        var list = if (showOnlyFavoritesMode) {
            // Map Room favorite channels to standard Channel entities
            favoriteChannels.map { Channel(it.id, it.name, it.logoUrl, it.streamUrl, it.category) }
        } else {
            channels.filter { it.category.equals(selectedCategory, ignoreCase = true) }
        }

        if (searchQuery.isNotBlank()) {
            // Search filters globally across all channels
            list = channels.filter {
                it.name.contains(searchQuery, ignoreCase = true) ||
                        it.category.contains(searchQuery, ignoreCase = true)
            }
        }
        list
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        if (isPipActive && activeStreamChannel != null) {
            // In PiP mode, render ONLY the video player to utilize 100% real estate
            IPTVPlayer(
                channel = activeStreamChannel!!,
                isLandscape = true,
                onClose = { viewModel.closePlayer() }
            )
        } else {
            // Standard layout
            Scaffold(
                modifier = Modifier.fillMaxSize(),
                containerColor = DarkBackground,
                topBar = {
                    Column {
                        HeaderSection(
                            appName = "IMU TV",
                            searchQuery = searchQuery,
                            onSearchQueryChanged = { viewModel.onSearchQueryChanged(it) },
                            showSearchRow = showSearchRow,
                            onToggleSearch = { showSearchRow = !showSearchRow },
                            isFavoriteFilterActive = showOnlyFavoritesMode,
                            onToggleFavoriteFilter = {
                                showOnlyFavoritesMode = !showOnlyFavoritesMode
                                if (showOnlyFavoritesMode) {
                                    showSearchRow = false
                                }
                            },
                            onRefresh = { viewModel.refresh() },
                            appUrl = "https://t.me/imustvsports"
                        )

                        if (notice.active) {
                            ScrollingNoticeBanner(notice = notice)
                        }
                    }
                },
                bottomBar = {
                    FooterSection(
                        onPrivacyClick = {
                            dialogTitle = "Privacy Policy"
                            dialogBody = "IMU TV respects your privacy. We do not collect, store, or share any personal identifying information, browsing history, or media consumption patterns. Stream contents are parsed live from third-party public links. We do not host any copyright contents."
                            showInfoDialog = true
                        },
                        onTermsClick = {
                            dialogTitle = "Terms & Conditions"
                            dialogBody = "Welcome to IMU TV. By using this application, you agree that streaming materials are fetched live via public sources. The service is provided 'as-is' without warranties of any kind. Users are solely responsible for local compliance with streaming regulations. MD Imam Hossain and IMU TV are not liable for external link uptimes."
                            showInfoDialog = true
                        }
                    )
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (isLoading) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            CircularProgressIndicator(color = CyberBlue)
                            Spacer(modifier = Modifier.height(16.dp))
                            Text("Loading Live Streams from Firebase...", color = Color.Gray)
                        }
                    } else {
                        Column(modifier = Modifier.fillMaxSize()) {
                            // Category Select chips (only show when not in search or pure favorites mode)
                            if (searchQuery.isBlank() && !showOnlyFavoritesMode) {
                                CategorySelectorChips(
                                    categories = categories,
                                    selectedCategory = selectedCategory,
                                    onCategorySelected = { viewModel.onCategorySelected(it) }
                                )
                            } else if (showOnlyFavoritesMode) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Favorite,
                                        contentDescription = null,
                                        tint = Color(0xFFFF5A14),
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Your Local Favorite Channels",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            } else {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Search,
                                        contentDescription = null,
                                        tint = CyberBlue,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Search results for: \"$searchQuery\"",
                                        style = MaterialTheme.typography.titleSmall,
                                        color = Color.LightGray
                                    )
                                }
                            }

                            // Dynamic 2-column channel list grid
                            if (filteredChannels.isEmpty()) {
                                EmptyState(showOnlyFavoritesMode)
                            } else {
                                Box(modifier = Modifier.weight(1f)) {
                                    LazyVerticalGrid(
                                        columns = GridCells.Fixed(2),
                                        contentPadding = PaddingValues(16.dp),
                                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                                        verticalArrangement = Arrangement.spacedBy(12.dp),
                                        modifier = Modifier.fillMaxSize()
                                    ) {
                                        items(filteredChannels, key = { it.id }) { ch ->
                                            ChannelGridCard(
                                                channel = ch,
                                                isFavorite = favoriteIds.contains(ch.id),
                                                onToggleFavorite = { viewModel.toggleFavorite(ch) },
                                                onClick = { viewModel.selectChannel(ch) }
                                            )
                                        }

                                        // Insert Telegram section dynamically at the bottom of list
                                        item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(2) }) {
                                            TelegramSectionCard(
                                                telegramLink = "https://t.me/imustvsports",
                                                onJoinClick = {
                                                    try {
                                                        val intent = Intent(
                                                            Intent.ACTION_VIEW,
                                                            Uri.parse("https://t.me/imustvsports")
                                                        )
                                                        context.startActivity(intent)
                                                    } catch (e: Exception) {
                                                        // Fallback
                                                    }
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Overlay: Full-screen 12s video ad countdown
            if (activeVideoAdChannel != null) {
                VideoAdPlayer(
                    targetChannel = activeVideoAdChannel!!,
                    adVideoUrl = adConfig.videoAdUrl,
                    timeRemaining = adTimeRemaining,
                    modifier = Modifier.fillMaxSize()
                )
            }

            // Overlay: Full-screen IPTV video player
            if (activeStreamChannel != null && activeVideoAdChannel == null) {
                val activity = context as? Activity
                val isLandscape = activity?.resources?.configuration?.orientation == Configuration.ORIENTATION_LANDSCAPE
                IPTVPlayer(
                    channel = activeStreamChannel!!,
                    isLandscape = isLandscape,
                    onClose = { viewModel.closePlayer() },
                    modifier = Modifier.fillMaxSize()
                )
            }

            // Overlay: Exit full-screen ad countdown
            if (showExitAd) {
                ExitAdOverlay(
                    timeRemaining = exitAdTimeRemaining,
                    onSkipExit = {
                        viewModel.dismissExitAd()
                        onExitActivity()
                    },
                    onCancel = { viewModel.dismissExitAd() }
                )
            }
        }

        // Custom Info Dialog
        if (showInfoDialog) {
            AlertDialog(
                onDismissRequest = { showInfoDialog = false },
                title = { Text(text = dialogTitle, fontWeight = FontWeight.Bold, color = Color.White) },
                text = { Text(text = dialogBody, color = Color.LightGray) },
                confirmButton = {
                    TextButton(onClick = { showInfoDialog = false }) {
                        Text("Close", color = CyberBlue)
                    }
                },
                containerColor = SurfaceDark,
                textContentColor = Color.LightGray,
                titleContentColor = Color.White
            )
        }

        // Telegram Join Popup
        if (showTelegramPopup) {
            TelegramJoinPopup(
                telegramLink = appSettings.telegramLink,
                onDismiss = { showTelegramPopup = false }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HeaderSection(
    appName: String,
    searchQuery: String,
    onSearchQueryChanged: (String) -> Unit,
    showSearchRow: Boolean,
    onToggleSearch: () -> Unit,
    isFavoriteFilterActive: Boolean,
    onToggleFavoriteFilter: () -> Unit,
    onRefresh: () -> Unit,
    appUrl: String
) {
    val context = LocalContext.current
    val keyboardController = LocalSoftwareKeyboardController.current

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkBackground)
            .windowInsetsPadding(WindowInsets.statusBars)
    ) {
        CenterAlignedTopAppBar(
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(36.dp)
                            .background(CyberBlue, RoundedCornerShape(10.dp))
                    ) {
                        Text(
                            text = "IMU",
                            color = ImmersiveSecondary,
                            fontWeight = FontWeight.Black,
                            style = MaterialTheme.typography.labelLarge,
                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                        )
                    }
                    Text(
                        text = appName,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = (-0.5).sp,
                        color = Color.White,
                        fontSize = 19.sp
                    )
                }
            },
            navigationIcon = {
                IconButton(
                    onClick = {
                        try {
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_SUBJECT, "IMU TV - Live IPTV Player")
                                putExtra(Intent.EXTRA_TEXT, "Watch professional Live IPTV channels, Sports, News & Movies on IMU TV! Download now: $appUrl")
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "Share IMU TV App"))
                        } catch (e: Exception) {
                            // handle fail
                        }
                    },
                    modifier = Modifier.testTag("share_button")
                ) {
                    Icon(imageVector = Icons.Default.Share, contentDescription = "Share App", tint = Color.LightGray)
                }
            },
            actions = {
                IconButton(
                    onClick = onToggleSearch,
                    modifier = Modifier.testTag("search_button")
                ) {
                    Icon(
                        imageVector = if (showSearchRow) Icons.Default.Close else Icons.Default.Search,
                        contentDescription = "Search",
                        tint = if (showSearchRow) CyberBlue else Color.LightGray
                    )
                }

                IconButton(
                    onClick = onToggleFavoriteFilter,
                    modifier = Modifier.testTag("favorite_button")
                ) {
                    Icon(
                        imageVector = if (isFavoriteFilterActive) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Favorites",
                        tint = if (isFavoriteFilterActive) CyberBlue else Color.LightGray
                    )
                }

                IconButton(
                    onClick = onRefresh,
                    modifier = Modifier.testTag("refresh_button")
                ) {
                    Icon(imageVector = Icons.Default.Refresh, contentDescription = "Refresh Data", tint = Color.LightGray)
                }
            },
            colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                containerColor = Color.Transparent
            )
        )

        // Expandable search bar Row
        AnimatedVisibility(
            visible = showSearchRow,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchQueryChanged,
                    placeholder = { Text("Search channel instantly...", color = Color.Gray) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_input"),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = SurfaceLighter,
                        unfocusedContainerColor = SurfaceLighter,
                        focusedBorderColor = CyberBlue,
                        unfocusedBorderColor = Color.DarkGray,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    trailingIcon = {
                        if (searchQuery.isNotBlank()) {
                            IconButton(onClick = { onSearchQueryChanged("") }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear", tint = Color.LightGray)
                            }
                        }
                    },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = {
                        keyboardController?.hide()
                    })
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ScrollingNoticeBanner(notice: Notice) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(ImmersiveSecondary.copy(alpha = 0.2f))
            .border(width = (0.5).dp, color = Color.White.copy(alpha = 0.05f))
            .padding(vertical = 10.dp, horizontal = 16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "UPDATE:",
                color = CyberBlue,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(end = 8.dp)
            )
            Text(
                text = notice.text,
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                modifier = Modifier.basicMarquee(
                    iterations = Int.MAX_VALUE,
                    repeatDelayMillis = 0
                )
            )
        }
    }
}

@Composable
fun CategorySelectorChips(
    categories: List<com.example.data.Category>,
    selectedCategory: String,
    onCategorySelected: (String) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 12.dp, bottom = 4.dp)
    ) {
        androidx.compose.foundation.lazy.LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(categories.size) { index ->
                val cat = categories[index]
                val isSelected = cat.name.equals(selectedCategory, ignoreCase = true)
                val chipBg = if (isSelected) CyberBlue else ImmersiveChipUnselected
                val chipText = if (isSelected) ImmersiveSecondary else TextSecondary
                val chipBorder = if (isSelected) Color.Transparent else Color.White.copy(alpha = 0.05f)

                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .clip(RoundedCornerShape(32.dp))
                        .background(chipBg)
                        .border(1.dp, chipBorder, RoundedCornerShape(32.dp))
                        .clickable { onCategorySelected(cat.name) }
                        .padding(horizontal = 18.dp, vertical = 10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Display matching icon per category if applicable
                        val icon = when (cat.name.lowercase()) {
                            "news" -> Icons.Default.Newspaper
                            "sports" -> Icons.Default.SportsSoccer
                            "kids" -> Icons.Default.Toys
                            "science" -> Icons.Default.Science
                            "music" -> Icons.Default.MusicNote
                            else -> Icons.Default.LiveTv
                        }
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = chipText,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = cat.name,
                            color = chipText,
                            fontSize = 13.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ChannelGridCard(
    channel: Channel,
    isFavorite: Boolean,
    onToggleFavorite: () -> Unit,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .border(0.5.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(16.dp))
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            Column {
                // Logo rendering with beautiful error fallbacks
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp)
                        .background(SurfaceLighter),
                    contentAlignment = Alignment.Center
                ) {
                    AsyncImage(
                        model = channel.logoUrl,
                        contentDescription = channel.name,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit,
                        error = painterResource(id = R.drawable.imu_tv_logo),
                        placeholder = painterResource(id = R.drawable.imu_tv_logo)
                    )
                }

                // Channel Name metadata label
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp)
                ) {
                    Text(
                        text = channel.name,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = channel.category.uppercase(),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyberBlue,
                        letterSpacing = 0.5.sp
                    )
                }
            }

            // Quick Toggle Favorite Button
            IconButton(
                onClick = onToggleFavorite,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(6.dp)
                    .size(32.dp)
                    .background(Color.Black.copy(alpha = 0.6f), CircleShape)
            ) {
                Icon(
                    imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = "Favorite Toggle",
                    tint = if (isFavorite) Color(0xFFFF5A14) else Color.White,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
fun TelegramSectionCard(
    telegramLink: String,
    onJoinClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 16.dp, bottom = 8.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(TelegramBlueStart, TelegramBlueEnd)
                    )
                )
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Official Telegram",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Join for live matches and links",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.9f)
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Button(
                onClick = onJoinClick,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White,
                    contentColor = TelegramBlueStart
                ),
                shape = RoundedCornerShape(32.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "Join Now",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    color = TelegramBlueStart
                )
            }
        }
    }
}

@Composable
fun EmptyState(isFavoritesMode: Boolean) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = if (isFavoritesMode) Icons.Default.FavoriteBorder else Icons.Default.Info,
            contentDescription = null,
            tint = Color.Gray,
            modifier = Modifier.size(56.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = if (isFavoritesMode) "No Favorite Channels Yet" else "No Channels Found",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = if (isFavoritesMode) "Mark channels as favorite to view them here instantly!" else "No dynamic channels match your query. Try pulling down to refresh.",
            style = MaterialTheme.typography.bodySmall,
            color = Color.Gray,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun FooterSection(
    onPrivacyClick: () -> Unit,
    onTermsClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxWidth()
            .background(SurfaceDark)
            .padding(vertical = 16.dp, horizontal = 24.dp)
    ) {
        Divider(color = Color.White.copy(alpha = 0.05f), modifier = Modifier.padding(bottom = 12.dp))

        Text(
            text = "Powered by MD Imam Hossain",
            fontSize = 10.sp,
            fontWeight = FontWeight.Medium,
            color = AccentTeal,
            letterSpacing = 0.5.sp
        )

        Spacer(modifier = Modifier.height(4.dp))

        Row(
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Privacy Policy",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = CyberBlue,
                modifier = Modifier
                    .clickable { onPrivacyClick() }
                    .padding(vertical = 4.dp)
            )

            Box(
                modifier = Modifier
                    .size(3.dp)
                    .background(AccentTeal, CircleShape)
            )

            Text(
                text = "Terms & Conditions",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = CyberBlue,
                modifier = Modifier
                    .clickable { onTermsClick() }
                    .padding(vertical = 4.dp)
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = "Copyright © 2024 IMU TV. All Rights Reserved.",
            fontSize = 10.sp,
            color = AccentTeal
        )
    }
}

@Composable
fun ExitAdOverlay(
    timeRemaining: Int,
    onSkipExit: () -> Unit,
    onCancel: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // High fidelity presentation ad
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
        ) {
            Icon(
                imageVector = Icons.Default.ExitToApp,
                contentDescription = null,
                tint = Color(0xFFFF5A14),
                modifier = Modifier.size(64.dp)
            )
            Spacer(modifier = Modifier.height(20.dp))
            Text(
                text = "Exiting IMU TV...",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Black,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "We hope you enjoyed live streaming with us! Powering down the dynamic links.",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.LightGray,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(40.dp))

            // Beautiful ad visual box representation
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF16161C))
                    .border(1.dp, Color(0xFFFF5A14).copy(alpha = 0.3f), RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Campaign,
                        contentDescription = null,
                        tint = Color(0xFFFF5A14),
                        modifier = Modifier.size(40.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Official Telegram Channel: @imustvsports",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "Join us now to suggest and request your custom TV channels!",
                        color = Color.Gray,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(start = 24.dp, end = 24.dp, top = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(40.dp))

            CircularProgressIndicator(
                color = Color(0xFFFF5A14),
                modifier = Modifier.size(36.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Closing application automatically in $timeRemaining seconds...",
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray
            )
        }

        // Action controls to let them skip immediately or go back
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .padding(24.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedButton(
                onClick = onCancel,
                border = BorderStroke(1.dp, Color.LightGray),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.LightGray)
            ) {
                Text("Cancel & Stay")
            }

            Button(
                onClick = onSkipExit,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF5A14))
            ) {
                Text("Exit Now", fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    }
}
