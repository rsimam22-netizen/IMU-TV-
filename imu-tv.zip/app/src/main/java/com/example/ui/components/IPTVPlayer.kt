package com.example.ui.components

import android.app.Activity
import android.content.Context
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.view.WindowManager
import androidx.annotation.OptIn
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.example.data.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.min

@OptIn(UnstableApi::class)
@Composable
fun IPTVPlayer(
    channel: Channel,
    isLandscape: Boolean,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val coroutineScope = rememberCoroutineScope()

    // ExoPlayer State
    var exoPlayer by remember { mutableStateOf<ExoPlayer?>(null) }
    var isPlaying by remember { mutableStateOf(true) }
    var isBuffering by remember { mutableStateOf(true) }
    var isError by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }

    // UI overlays & lock
    var showControls by remember { mutableStateOf(true) }
    var isLocked by remember { mutableStateOf(false) }

    // Gestures states
    var gestureType by remember { mutableStateOf<String?>(null) } // "volume" or "brightness"
    var gestureValue by remember { mutableStateOf(0f) } // 0f to 1f
    var showGestureIndicator by remember { mutableStateOf(false) }

    // Services
    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVolume = remember { audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).toFloat() }

    // Fetch initial brightness
    var currentBrightness by remember {
        mutableStateOf(
            activity?.window?.attributes?.screenBrightness ?: 0.5f
        )
    }
    if (currentBrightness < 0) currentBrightness = 0.5f // system default standard fallback

    // Auto-hide controls timer
    LaunchedEffect(showControls) {
        if (showControls && !isLocked) {
            delay(5000)
            showControls = false
        }
    }

    // Initialize ExoPlayer
    DisposableEffect(channel.streamUrl) {
        val player = ExoPlayer.Builder(context).build().apply {
            playWhenReady = true
            val mediaItem = MediaItem.fromUri(channel.streamUrl)
            setMediaItem(mediaItem)
            prepare()
        }

        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                isBuffering = state == Player.STATE_BUFFERING
                if (state == Player.STATE_READY) {
                    isError = false
                    isPlaying = player.isPlaying
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                isBuffering = false
                isError = true
                errorMessage = error.localizedMessage ?: "Stream source unavailable"
            }

            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }
        }

        player.addListener(listener)
        exoPlayer = player

        onDispose {
            player.removeListener(listener)
            player.release()
            exoPlayer = null
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(isLocked) {
                detectVerticalDragGestures(
                    onDragStart = { offset ->
                        if (isLocked) return@detectVerticalDragGestures
                        val screenWidth = size.width
                        if (offset.x < screenWidth / 2) {
                            gestureType = "Brightness"
                            gestureValue = currentBrightness
                        } else {
                            gestureType = "Volume"
                            val currentVol =
                                audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                            gestureValue = currentVol / maxVolume
                        }
                        showGestureIndicator = true
                    },
                    onDragEnd = {
                        showGestureIndicator = false
                        gestureType = null
                    },
                    onDragCancel = {
                        showGestureIndicator = false
                        gestureType = null
                    },
                    onVerticalDrag = { _, dragAmount ->
                        if (isLocked) return@detectVerticalDragGestures
                        // dragging up is negative, dragging down is positive
                        val sensitivity = 0.005f
                        val delta = -dragAmount * sensitivity
                        gestureValue = min(1f, max(0f, gestureValue + delta))

                        if (gestureType == "Brightness") {
                            currentBrightness = gestureValue
                            activity?.let { act ->
                                val lp = act.window.attributes
                                lp.screenBrightness = gestureValue
                                act.window.attributes = lp
                            }
                        } else if (gestureType == "Volume") {
                            val targetVol = (gestureValue * maxVolume).toInt()
                            audioManager.setStreamVolume(
                                AudioManager.STREAM_MUSIC,
                                targetVol,
                                0
                            )
                        }
                    }
                )
            }
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) {
                showControls = !showControls
            }
    ) {
        // Video View
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    useController = false // Use custom Compose controller UI instead
                    player = exoPlayer
                    keepScreenOn = true
                }
            },
            update = { view ->
                view.player = exoPlayer
            },
            modifier = Modifier.fillMaxSize()
        )

        // Gradient overlay for better control text readability
        AnimatedVisibility(
            visible = showControls,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Black.copy(alpha = 0.7f),
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.7f)
                            )
                        )
                    )
                )
        }

        // Gesture HUD Indicators
        AnimatedVisibility(
            visible = showGestureIndicator && gestureType != null,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.Center)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = 0.8f)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.padding(16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp)
                ) {
                    Icon(
                        imageVector = if (gestureType == "Brightness") Icons.Default.Brightness5 else Icons.Default.VolumeUp,
                        contentDescription = gestureType,
                        tint = if (gestureType == "Brightness") Color(0xFFFFA000) else Color(0xFF00B2FF),
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = gestureType ?: "",
                            style = MaterialTheme.typography.labelMedium,
                            color = Color.LightGray
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        LinearProgressIndicator(
                            progress = { gestureValue },
                            color = if (gestureType == "Brightness") Color(0xFFFFA000) else Color(0xFF00B2FF),
                            trackColor = Color.DarkGray,
                            modifier = Modifier
                                .width(120.dp)
                                .height(8.dp)
                                .clip(CircleShape)
                        )
                    }
                }
            }
        }

        // Top Controls: Title and close
        AnimatedVisibility(
            visible = showControls && !isLocked,
            enter = slideInVertically { -it } + fadeIn(),
            exit = slideOutVertically { -it } + fadeOut(),
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.statusBars)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                IconButton(
                    onClick = onClose,
                    modifier = Modifier
                        .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                        .testTag("player_back_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }

                Spacer(modifier = Modifier.width(16.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = channel.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "IPTV HD HLS • ${channel.category}",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.LightGray
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // PiP Button
                IconButton(
                    onClick = {
                        try {
                            activity?.enterPictureInPictureMode()
                        } catch (e: Exception) {
                            // PiP not supported
                        }
                    },
                    modifier = Modifier.background(Color.Black.copy(alpha = 0.5f), CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.PictureInPicture,
                        contentDescription = "Picture in Picture",
                        tint = Color.White
                    )
                }
            }
        }

        // Center buffering state
        if (isBuffering) {
            CircularProgressIndicator(
                color = Color(0xFF00B2FF),
                modifier = Modifier
                    .size(64.dp)
                    .align(Alignment.Center)
            )
        }

        // Error display overlay
        if (isError) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .padding(32.dp)
                    .align(Alignment.Center)
                    .background(Color.Black.copy(alpha = 0.8f), RoundedCornerShape(16.dp))
                    .padding(24.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ErrorOutline,
                    contentDescription = "Playback Error",
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(56.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Failed to Stream Channel",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = errorMessage,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.LightGray,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = {
                        isBuffering = true
                        isError = false
                        exoPlayer?.let { player ->
                            player.setMediaItem(MediaItem.fromUri(channel.streamUrl))
                            player.prepare()
                            player.play()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00B2FF))
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Retry Link", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Center Controls (Play/Pause)
        AnimatedVisibility(
            visible = showControls && !isLocked && !isError,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.Center)
        ) {
            IconButton(
                onClick = {
                    exoPlayer?.let { player ->
                        if (isPlaying) {
                            player.pause()
                        } else {
                            player.play()
                        }
                        isPlaying = !isPlaying
                    }
                },
                modifier = Modifier
                    .size(80.dp)
                    .background(Color.Black.copy(alpha = 0.6f), CircleShape)
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (isPlaying) "Pause" else "Play",
                    tint = Color.White,
                    modifier = Modifier.size(48.dp)
                )
            }
        }

        // Bottom Controls: Rotation toggle, Lock
        AnimatedVisibility(
            visible = showControls,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 24.dp, vertical = 16.dp)
            ) {
                // Lock Button
                IconButton(
                    onClick = {
                        isLocked = !isLocked
                        showControls = true
                    },
                    modifier = Modifier.background(
                        if (isLocked) Color(0xFFFF5A14).copy(alpha = 0.8f) else Color.Black.copy(alpha = 0.5f),
                        CircleShape
                    )
                ) {
                    Icon(
                        imageVector = if (isLocked) Icons.Default.Lock else Icons.Default.LockOpen,
                        contentDescription = "Lock Controls",
                        tint = Color.White
                    )
                }

                if (!isLocked) {
                    // Force orientation toggle button
                    IconButton(
                        onClick = {
                            activity?.requestedOrientation = if (isLandscape) {
                                ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                            } else {
                                ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                            }
                        },
                        modifier = Modifier.background(Color.Black.copy(alpha = 0.5f), CircleShape)
                    ) {
                        Icon(
                            imageVector = if (isLandscape) Icons.Default.ScreenLockPortrait else Icons.Default.ScreenRotation,
                            contentDescription = "Rotate Screen",
                            tint = Color.White
                        )
                    }
                }
            }
        }
    }
}
