package com.example.data

import android.content.Context
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

class IPTVRepository(private val context: Context) {

    private val db = AppDatabase.getDatabase(context)
    private val dao = db.favoriteDao()

    private val _channels = MutableStateFlow<List<Channel>>(emptyList())
    val channels: StateFlow<List<Channel>> = _channels.asStateFlow()

    private val _categories = MutableStateFlow<List<Category>>(emptyList())
    val categories: StateFlow<List<Category>> = _categories.asStateFlow()

    private val _notice = MutableStateFlow<Notice>(Notice("Welcome to IMU TV IPTV player!", true))
    val notice: StateFlow<Notice> = _notice.asStateFlow()

    private val _adConfig = MutableStateFlow<AdConfig>(AdConfig("", 12))
    val adConfig: StateFlow<AdConfig> = _adConfig.asStateFlow()

    private val _appSettings = MutableStateFlow<AppSettings>(AppSettings())
    val appSettings: StateFlow<AppSettings> = _appSettings.asStateFlow()

    private val _isLoading = MutableStateFlow(true)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

    private val coroutineScope = CoroutineScope(Dispatchers.IO)

    init {
        initFirebaseAndSync()
    }

    private fun initFirebaseAndSync() {
        try {
            if (FirebaseApp.getApps(context).isEmpty()) {
                val options = FirebaseOptions.Builder()
                    .setApiKey("AIzaSyCzYG8xus2jjV-AlhesNovD7u0SuASR_JU")
                    .setApplicationId("1:6965642874:web:e30959ba5be8fe8c715dc3")
                    .setDatabaseUrl("https://imu-tv-2c753-default-rtdb.asia-southeast1.firebasedatabase.app")
                    .setProjectId("imu-tv-2c753")
                    .setStorageBucket("imu-tv-2c753.firebasestorage.app")
                    .setGcmSenderId("6965642874")
                    .build()
                FirebaseApp.initializeApp(context, options)
                Log.d("IPTVRepository", "Firebase Initialized successfully with programmatic options.")
            }
            startSyncing()
        } catch (e: Exception) {
            Log.e("IPTVRepository", "Error initializing Firebase: ${e.message}", e)
            loadFallbackLocalData()
        }
    }

    fun startSyncing() {
        _isLoading.value = true
        val database = FirebaseDatabase.getInstance()

        // Sync Notices
        database.getReference("notices").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val noticeObj = snapshot.getValue(Notice::class.java)
                if (noticeObj != null) {
                    _notice.value = noticeObj
                } else {
                    // Seed notice
                    val defaultNotice = Notice("Welcome to IMU TV! Powered by MD Imam Hossain. Join our Official Telegram Channel t.me/imustvsports for updates and requests!", true)
                    database.getReference("notices").setValue(defaultNotice)
                    _notice.value = defaultNotice
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("IPTVRepository", "Notice sync cancelled: ${error.message}")
            }
        })

        // Sync AdConfig
        database.getReference("ads").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val config = snapshot.getValue(AdConfig::class.java)
                if (config != null) {
                    _adConfig.value = config
                } else {
                    // Seed ad config
                    val defaultAd = AdConfig(
                        videoAdUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
                        durationSeconds = 12
                    )
                    database.getReference("ads").setValue(defaultAd)
                    _adConfig.value = defaultAd
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("IPTVRepository", "Ad sync cancelled: ${error.message}")
            }
        })

        // Sync AppSettings
        database.getReference("app_settings").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val settings = snapshot.getValue(AppSettings::class.java)
                if (settings != null) {
                    _appSettings.value = settings
                } else {
                    val defaultSettings = AppSettings()
                    database.getReference("app_settings").setValue(defaultSettings)
                    _appSettings.value = defaultSettings
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("IPTVRepository", "App settings sync cancelled: ${error.message}")
            }
        })

        // Sync Categories
        database.getReference("categories").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val list = mutableListOf<Category>()
                for (child in snapshot.children) {
                    val cat = child.getValue(Category::class.java)
                    if (cat != null) list.add(cat)
                }
                if (list.isEmpty()) {
                    seedDefaultCategories(database)
                } else {
                    _categories.value = list
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("IPTVRepository", "Categories sync cancelled: ${error.message}")
            }
        })

        // Sync Channels
        database.getReference("channels").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val list = mutableListOf<Channel>()
                for (child in snapshot.children) {
                    val ch = child.getValue(Channel::class.java)
                    if (ch != null) list.add(ch)
                }
                if (list.isEmpty()) {
                    seedDefaultChannels(database)
                } else {
                    _channels.value = list
                    _isLoading.value = false
                    _isRefreshing.value = false
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("IPTVRepository", "Channels sync cancelled: ${error.message}")
                _isLoading.value = false
                _isRefreshing.value = false
            }
        })
    }

    fun refreshData() {
        coroutineScope.launch {
            _isRefreshing.value = true
            try {
                // Trigger a refresh of the listeners
                startSyncing()
            } catch (e: Exception) {
                _isRefreshing.value = false
            }
        }
    }

    private fun seedDefaultCategories(database: FirebaseDatabase) {
        val defaultCats = listOf(
            Category("News", "News"),
            Category("Sports", "Sports"),
            Category("Kids", "Kids"),
            Category("Science", "Science"),
            Category("Music", "Music")
        )
        val ref = database.getReference("categories")
        for (cat in defaultCats) {
            ref.child(cat.id).setValue(cat)
        }
        _categories.value = defaultCats
    }

    private fun seedDefaultChannels(database: FirebaseDatabase) {
        val defaultChs = getFallbackChannelsList()
        val ref = database.getReference("channels")
        for (ch in defaultChs) {
            ref.child(ch.id).setValue(ch)
        }
        _channels.value = defaultChs
        _isLoading.value = false
        _isRefreshing.value = false
    }

    private fun loadFallbackLocalData() {
        _categories.value = listOf(
            Category("News", "News"),
            Category("Sports", "Sports"),
            Category("Kids", "Kids"),
            Category("Science", "Science"),
            Category("Music", "Music")
        )
        _channels.value = getFallbackChannelsList()
        _isLoading.value = false
        _isRefreshing.value = false
    }

    private fun getFallbackChannelsList(): List<Channel> {
        return listOf(
            // News
            Channel("sky_news", "Sky News English", "https://i.imgur.com/z2fR7Nq.png", "https://shaun-ews.github.io/news/sky.m3u8", "News"),
            Channel("aljazeera_news", "Al Jazeera English", "https://i.imgur.com/LNoWunQ.png", "https://live-amg-el.akamaized.net/playlist.m3u8", "News"),
            Channel("dw_news", "DW News Global", "https://i.imgur.com/76U5YhX.png", "https://dwamdstream102.akamaized.net/hls/live/2015532/dwamdstream102/index.m3u8", "News"),
            
            // Sports
            Channel("redbull_sports", "Red Bull Sports", "https://i.imgur.com/M6LgO0b.png", "https://rbmn-live.akamaized.net/hls/live/590964/bo-sports/index.m3u8", "Sports"),
            Channel("edge_sports", "Edge Sport TV", "https://i.imgur.com/9lQyXf0.png", "https://edgesport-edge.amagi.tv/playlist.m3u8", "Sports"),
            
            // Kids
            Channel("pbs_kids", "PBS Kids Live", "https://i.imgur.com/U899TzT.png", "https://pbskids-lh.akamaihd.net/i/pbskids_hd@355659/index_3000_av-p.m3u8", "Kids"),
            Channel("classic_cartoons", "Classic Animation TV", "https://i.imgur.com/lO1B2Pz.png", "https://classiccartoon-lh.akamaihd.net/i/classic_1@352352/master.m3u8", "Kids"),

            // Science
            Channel("nasa_tv", "NASA TV LIVE", "https://i.imgur.com/5O4zZtW.png", "https://ntv1.akamaized.net/hls/live/2014027/NASA-NTV1-HLS/master.m3u8", "Science"),
            Channel("space_channel", "Space Exploration TV", "https://i.imgur.com/eE2k8lC.png", "https://spacechannel.sinclair-edge.com/playlist.m3u8", "Science"),

            // Music
            Channel("clubbing_tv", "Clubbing Electronic TV", "https://i.imgur.com/VpLg9F4.png", "https://clubbingtv-ott-live.b-cdn.net/bpk-tv/clubbingtv/default/index.m3u8", "Music"),
            Channel("redbull_music", "Red Bull Stage Music", "https://i.imgur.com/C7Kx2OQ.png", "https://rbmn-live.akamaized.net/hls/live/590964/bo-austria/index.m3u8", "Music")
        )
    }

    // Favorites Room Integration
    fun getAllLocalFavorites(): Flow<List<FavoriteChannel>> = dao.getAllFavorites()

    suspend fun addChannelToFavorite(channel: Channel) {
        dao.insertFavorite(
            FavoriteChannel(
                id = channel.id,
                name = channel.name,
                logoUrl = channel.logoUrl,
                streamUrl = channel.streamUrl,
                category = channel.category
            )
        )
    }

    suspend fun removeChannelFromFavorite(channelId: String) {
        dao.deleteFavoriteById(channelId)
    }

    suspend fun isChannelFavorite(channelId: String): Boolean = dao.isFavorite(channelId)
}
