package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "favorite_channels")
data class FavoriteChannel(
    @PrimaryKey val id: String,
    val name: String,
    val logoUrl: String,
    val streamUrl: String,
    val category: String
)
