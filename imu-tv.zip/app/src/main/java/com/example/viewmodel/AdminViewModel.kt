package com.example.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class AdminViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = AdminRepository(application.applicationContext)

    private val _isLoggedIn = MutableStateFlow(false)
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private val _userEmail = MutableStateFlow("")
    val userEmail: StateFlow<String> = _userEmail.asStateFlow()

    private val _categories = MutableStateFlow<List<Category>>(emptyList())
    val categories: StateFlow<List<Category>> = _categories.asStateFlow()

    private val _channels = MutableStateFlow<List<Channel>>(emptyList())
    val channels: StateFlow<List<Channel>> = _channels.asStateFlow()

    private val _ads = MutableStateFlow<Map<String, Ad>>(emptyMap())
    val ads: StateFlow<Map<String, Ad>> = _ads.asStateFlow()

    private val _notices = MutableStateFlow<List<NoticeItem>>(emptyList())
    val notices: StateFlow<List<NoticeItem>> = _notices.asStateFlow()

    private val _settings = MutableStateFlow(AppSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _uploadProgress = MutableStateFlow(0.0)
    val uploadProgress: StateFlow<Double> = _uploadProgress.asStateFlow()

    private val _isUploading = MutableStateFlow(false)
    val isUploading: StateFlow<Boolean> = _isUploading.asStateFlow()

    private val _successMessage = MutableStateFlow<String?>(null)
    val successMessage: StateFlow<String?> = _successMessage.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private var categoriesListener: ValueEventListener? = null
    private var channelsListener: ValueEventListener? = null
    private var adsListener: ValueEventListener? = null
    private var noticesListener: ValueEventListener? = null
    private var settingsListener: ValueEventListener? = null

    init {
        checkLoginStatus()
    }

    fun checkLoginStatus() {
        val loggedIn = repository.isUserLoggedIn()
        _isLoggedIn.value = loggedIn
        if (loggedIn) {
            _userEmail.value = repository.getCurrentUserEmail()
            startListening()
        } else {
            stopListening()
        }
    }

    fun login(email: String, password: String) {
        _isLoading.value = true
        repository.login(email, password,
            onSuccess = {
                _isLoading.value = false
                _isLoggedIn.value = true
                _userEmail.value = repository.getCurrentUserEmail()
                _successMessage.value = "Welcome back, Admin!"
                startListening()
            },
            onFailure = { error ->
                _isLoading.value = false
                _errorMessage.value = error
            }
        )
    }

    fun logout() {
        repository.logout()
        _isLoggedIn.value = false
        _userEmail.value = ""
        stopListening()
        _successMessage.value = "Logged out successfully"
    }

    private fun startListening() {
        stopListening()
        _isLoading.value = true

        categoriesListener = repository.getCategories(
            onDataChange = { list ->
                _categories.value = list
                _isLoading.value = false
            },
            onError = { err ->
                _isLoading.value = false
                _errorMessage.value = "Failed to load categories: $err"
            }
        )

        channelsListener = repository.getChannels(
            onDataChange = { list ->
                _channels.value = list
            },
            onError = { err ->
                _errorMessage.value = "Failed to load channels: $err"
            }
        )

        adsListener = repository.getAds(
            onDataChange = { map ->
                _ads.value = map
            },
            onError = { err ->
                _errorMessage.value = "Failed to load ads: $err"
            }
        )

        noticesListener = repository.getNotices(
            onDataChange = { list ->
                _notices.value = list
            },
            onError = { err ->
                _errorMessage.value = "Failed to load notices: $err"
            }
        )

        settingsListener = repository.getSettings(
            onDataChange = { set ->
                _settings.value = set
            },
            onError = { err ->
                _errorMessage.value = "Failed to load settings: $err"
            }
        )
    }

    private fun stopListening() {
        categoriesListener?.let { repository.removeListener(it) }
        channelsListener?.let { repository.removeListener(it) }
        adsListener?.let { repository.removeListener(it) }
        noticesListener?.let { repository.removeListener(it) }
        settingsListener?.let { repository.removeListener(it) }

        categoriesListener = null
        channelsListener = null
        adsListener = null
        noticesListener = null
        settingsListener = null
    }

    fun clearMessages() {
        _successMessage.value = null
        _errorMessage.value = null
    }

    // --- Category Management ---
    fun addCategory(name: String) {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) {
            _errorMessage.value = "Category name cannot be empty"
            return
        }
        _isLoading.value = true
        repository.addCategory(Category(name = trimmed),
            onSuccess = {
                _isLoading.value = false
                _successMessage.value = "Category '$trimmed' added successfully"
            },
            onFailure = { err ->
                _isLoading.value = false
                _errorMessage.value = err
            }
        )
    }

    fun updateCategory(id: String, name: String) {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) {
            _errorMessage.value = "Category name cannot be empty"
            return
        }
        _isLoading.value = true
        repository.updateCategory(Category(id = id, name = trimmed),
            onSuccess = {
                _isLoading.value = false
                _successMessage.value = "Category updated successfully"
            },
            onFailure = { err ->
                _isLoading.value = false
                _errorMessage.value = err
            }
        )
    }

    fun deleteCategory(id: String) {
        _isLoading.value = true
        repository.deleteCategory(id,
            onSuccess = {
                _isLoading.value = false
                _successMessage.value = "Category deleted successfully"
            },
            onFailure = { err ->
                _isLoading.value = false
                _errorMessage.value = err
            }
        )
    }

    // --- Channel Management ---
    fun addChannel(name: String, logoUrl: String, streamUrl: String, category: String, active: Boolean) {
        val trimmedName = name.trim()
        val trimmedStream = streamUrl.trim()
        if (trimmedName.isEmpty() || trimmedStream.isEmpty() || category.isEmpty()) {
            _errorMessage.value = "Please fill in all required fields"
            return
        }
        _isLoading.value = true
        val channel = Channel(
            name = trimmedName,
            logoUrl = logoUrl.trim(),
            streamUrl = trimmedStream,
            category = category,
            active = active
        )
        repository.addChannel(channel,
            onSuccess = {
                _isLoading.value = false
                _successMessage.value = "Channel '$trimmedName' added successfully"
            },
            onFailure = { err ->
                _isLoading.value = false
                _errorMessage.value = err
            }
        )
    }

    fun updateChannel(id: String, name: String, logoUrl: String, streamUrl: String, category: String, active: Boolean) {
        val trimmedName = name.trim()
        val trimmedStream = streamUrl.trim()
        if (trimmedName.isEmpty() || trimmedStream.isEmpty() || category.isEmpty()) {
            _errorMessage.value = "Please fill in all required fields"
            return
        }
        _isLoading.value = true
        val channel = Channel(
            id = id,
            name = trimmedName,
            logoUrl = logoUrl.trim(),
            streamUrl = trimmedStream,
            category = category,
            active = active
        )
        repository.updateChannel(channel,
            onSuccess = {
                _isLoading.value = false
                _successMessage.value = "Channel updated successfully"
            },
            onFailure = { err ->
                _isLoading.value = false
                _errorMessage.value = err
            }
        )
    }

    fun deleteChannel(id: String) {
        _isLoading.value = true
        repository.deleteChannel(id,
            onSuccess = {
                _isLoading.value = false
                _successMessage.value = "Channel deleted successfully"
            },
            onFailure = { err ->
                _isLoading.value = false
                _errorMessage.value = err
            }
        )
    }

    // --- Advertisement Management ---
    fun saveAd(id: String, videoUrl: String, enabled: Boolean) {
        _isLoading.value = true
        val ad = Ad(id = id, videoUrl = videoUrl.trim(), enabled = enabled)
        repository.saveAd(ad,
            onSuccess = {
                _isLoading.value = false
                _successMessage.value = "Advertisement updated successfully"
            },
            onFailure = { err ->
                _isLoading.value = false
                _errorMessage.value = err
            }
        )
    }

    // --- Notice Management ---
    fun addNotice(text: String, active: Boolean) {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) {
            _errorMessage.value = "Notice text cannot be empty"
            return
        }
        _isLoading.value = true
        repository.addNotice(NoticeItem(text = trimmed, active = active),
            onSuccess = {
                _isLoading.value = false
                _successMessage.value = "Notice added successfully"
            },
            onFailure = { err ->
                _isLoading.value = false
                _errorMessage.value = err
            }
        )
    }

    fun updateNotice(id: String, text: String, active: Boolean) {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) {
            _errorMessage.value = "Notice text cannot be empty"
            return
        }
        _isLoading.value = true
        repository.updateNotice(NoticeItem(id = id, text = trimmed, active = active),
            onSuccess = {
                _isLoading.value = false
                _successMessage.value = "Notice updated successfully"
            },
            onFailure = { err ->
                _isLoading.value = false
                _errorMessage.value = err
            }
        )
    }

    fun deleteNotice(id: String) {
        _isLoading.value = true
        repository.deleteNotice(id,
            onSuccess = {
                _isLoading.value = false
                _successMessage.value = "Notice deleted successfully"
            },
            onFailure = { err ->
                _isLoading.value = false
                _errorMessage.value = err
            }
        )
    }

    // --- Settings Management ---
    fun saveSettings(
        appName: String,
        footerText: String,
        telegramLink: String,
        shareLink: String,
        privacyPolicy: String,
        termsConditions: String,
        appLogoUrl: String
    ) {
        val trimmedAppName = appName.trim()
        if (trimmedAppName.isEmpty()) {
            _errorMessage.value = "App Name cannot be empty"
            return
        }
        _isLoading.value = true
        val set = AppSettings(
            appName = trimmedAppName,
            footerText = footerText.trim(),
            telegramLink = telegramLink.trim(),
            shareLink = shareLink.trim(),
            privacyPolicy = privacyPolicy.trim(),
            termsConditions = termsConditions.trim(),
            appLogoUrl = appLogoUrl.trim()
        )
        repository.saveSettings(set,
            onSuccess = {
                _isLoading.value = false
                _successMessage.value = "Settings saved successfully"
            },
            onFailure = { err ->
                _isLoading.value = false
                _errorMessage.value = err
            }
        )
    }

    // --- File Upload ---
    fun uploadFile(uri: Uri, folderName: String, fileName: String, onUploaded: (String) -> Unit) {
        _isUploading.value = true
        _uploadProgress.value = 0.0
        repository.uploadFile(
            uri = uri,
            folderName = folderName,
            fileName = fileName,
            onProgress = { progress ->
                _uploadProgress.value = progress
            },
            onSuccess = { downloadUrl ->
                _isUploading.value = false
                _successMessage.value = "File uploaded successfully!"
                onUploaded(downloadUrl)
            },
            onFailure = { err ->
                _isUploading.value = false
                _errorMessage.value = "Upload failed: $err"
            }
        )
    }

    override fun onCleared() {
        super.onCleared()
        stopListening()
    }
}
