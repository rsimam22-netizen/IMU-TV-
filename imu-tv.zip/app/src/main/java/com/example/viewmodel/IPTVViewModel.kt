package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class IPTVViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = IPTVRepository(application)

    // Data streams from Firebase
    val channels: StateFlow<List<Channel>> = repository.channels
    val categories: StateFlow<List<Category>> = repository.categories
    val notice: StateFlow<Notice> = repository.notice
    val adConfig: StateFlow<AdConfig> = repository.adConfig
    val appSettings: StateFlow<AppSettings> = repository.appSettings
    val isLoading: StateFlow<Boolean> = repository.isLoading
    val isRefreshing: StateFlow<Boolean> = repository.isRefreshing

    // Local UI state
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("News") // default category
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    // Favorites cache
    private val _favoriteChannels = MutableStateFlow<List<FavoriteChannel>>(emptyList())
    val favoriteChannels: StateFlow<List<FavoriteChannel>> = _favoriteChannels.asStateFlow()

    private val _favoriteIds = MutableStateFlow<Set<String>>(emptySet())
    val favoriteIds: StateFlow<Set<String>> = _favoriteIds.asStateFlow()

    // Ad & Player states
    private val _activeVideoAdChannel = MutableStateFlow<Channel?>(null)
    val activeVideoAdChannel: StateFlow<Channel?> = _activeVideoAdChannel.asStateFlow()

    private val _adTimeRemaining = MutableStateFlow(12)
    val adTimeRemaining: StateFlow<Int> = _adTimeRemaining.asStateFlow()

    private val _activeStreamChannel = MutableStateFlow<Channel?>(null)
    val activeStreamChannel: StateFlow<Channel?> = _activeStreamChannel.asStateFlow()

    // Exit Ad state
    private val _showExitAd = MutableStateFlow(false)
    val showExitAd: StateFlow<Boolean> = _showExitAd.asStateFlow()

    private val _exitAdTimeRemaining = MutableStateFlow(5)
    val exitAdTimeRemaining: StateFlow<Int> = _exitAdTimeRemaining.asStateFlow()

    private var adCountdownJob: Job? = null
    private var exitAdCountdownJob: Job? = null

    init {
        // Observe Room favorites and cache them
        viewModelScope.launch {
            repository.getAllLocalFavorites().collect { favs ->
                _favoriteChannels.value = favs
                _favoriteIds.value = favs.map { it.id }.toSet()
            }
        }
    }

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
    }

    fun onCategorySelected(category: String) {
        _selectedCategory.value = category
    }

    fun refresh() {
        repository.refreshData()
    }

    // Toggle Favorite
    fun toggleFavorite(channel: Channel) {
        viewModelScope.launch {
            if (_favoriteIds.value.contains(channel.id)) {
                repository.removeChannelFromFavorite(channel.id)
            } else {
                repository.addChannelToFavorite(channel)
            }
        }
    }

    // Select channel (triggers 12-second full screen video ad before stream starts)
    fun selectChannel(channel: Channel) {
        adCountdownJob?.cancel()
        _activeStreamChannel.value = null // clear current playing stream
        _activeVideoAdChannel.value = channel
        _adTimeRemaining.value = 12

        adCountdownJob = viewModelScope.launch {
            while (_adTimeRemaining.value > 0) {
                delay(1000)
                _adTimeRemaining.value -= 1
            }
            // Ad completed, auto start IPTV stream
            _activeVideoAdChannel.value = null
            _activeStreamChannel.value = channel
        }
    }

    fun closePlayer() {
        _activeStreamChannel.value = null
        _activeVideoAdChannel.value = null
        adCountdownJob?.cancel()
    }

    // Exit request: triggers exit ad
    fun triggerExitAd(onAdFinishedAndExit: () -> Unit) {
        exitAdCountdownJob?.cancel()
        _showExitAd.value = true
        _exitAdTimeRemaining.value = 5 // 5 second exit ad presentation

        exitAdCountdownJob = viewModelScope.launch {
            while (_exitAdTimeRemaining.value > 0) {
                delay(1000)
                _exitAdTimeRemaining.value -= 1
            }
            _showExitAd.value = false
            onAdFinishedAndExit()
        }
    }

    fun dismissExitAd() {
        _showExitAd.value = false
        exitAdCountdownJob?.cancel()
    }
}
