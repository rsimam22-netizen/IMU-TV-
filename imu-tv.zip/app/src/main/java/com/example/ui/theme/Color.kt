package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberBlue = Color(0xFFD0BCFF) // Immersive Primary Purple
val NeonOrange = Color(0xFFFF5A14)
val DarkBackground = Color(0xFF1A1C1E) // Immersive Background
val SurfaceDark = Color(0xFF1C1B1F) // Immersive Surface
val SurfaceLighter = Color(0xFF2E2D35) // Surface variant / input fields
val TextPrimary = Color(0xFFE2E2E6) // Immersive TextPrimary
val TextSecondary = Color(0xFFCAC4D0) // Immersive TextSecondary
val AccentTeal = Color(0xFF938F99) // Muted Gray-Purple
val ImmersiveSecondary = Color(0xFF381E72) // Immersive Deep Purple
val ImmersiveChipUnselected = Color(0xFF49454F) // Unselected chip bg
val TelegramBlueStart = Color(0xFF0088CC)
val TelegramBlueEnd = Color(0xFF00A2FF)


