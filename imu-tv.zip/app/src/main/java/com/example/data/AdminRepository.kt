package com.example.data

import android.content.Context
import android.net.Uri
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.storage.FirebaseStorage
import java.io.InputStream
import java.util.UUID

class AdminRepository(private val context: Context) {

    private val auth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }
    private val database: FirebaseDatabase by lazy { FirebaseDatabase.getInstance() }
    private val storage: FirebaseStorage by lazy { FirebaseStorage.getInstance() }

    init {
        initFirebase()
    }

    private fun initFirebase() {
        try {
            if (FirebaseApp.getApps(context).isEmpty()) {
                val options = FirebaseOptions.Builder()
                    .setApiKey("AIzaSyCzYG8xus2jjV-AlhesNovD7u0SuASR_JU")
                    .setApplicationId("1:6965642874:web:e30959ba5be8fe8c715dc3")
                    .setDatabaseUrl("https://imu-tv-2c753-default-rtdb.asia-southeast1.firebasedatabase.app")
                    .setProjectId("imu-tv-2c753")
                    .setStorageBucket("imu-tv-2c753.firebasestorage.app")
                    .setGcmSenderId("6965642874")
                    .build()
                FirebaseApp.initializeApp(context, options)
                Log.d("AdminRepository", "Firebase Initialized successfully in Admin.")
            }
        } catch (e: Exception) {
            Log.e("AdminRepository", "Error initializing Firebase: ${e.message}", e)
        }
    }

    // --- Authentication ---
    fun login(email: String, password: String, onSuccess: () -> Unit, onFailure: (String) -> Unit) {
        auth.signInWithEmailAndPassword(email, password)
            .addOnSuccessListener {
                onSuccess()
            }
            .addOnFailureListener { exception ->
                val errorMessage = exception.localizedMessage ?: ""
                val isInvalidCredentials = exception is com.google.firebase.auth.FirebaseAuthInvalidUserException ||
                        exception is com.google.firebase.auth.FirebaseAuthInvalidCredentialsException ||
                        errorMessage.contains("invalid-login-credentials", ignoreCase = true) ||
                        errorMessage.contains("USER_NOT_FOUND", ignoreCase = true)

                if (isInvalidCredentials) {
                    // Try to auto-register the admin if they don't exist in authentication list
                    auth.createUserWithEmailAndPassword(email, password)
                        .addOnSuccessListener {
                            onSuccess()
                        }
                        .addOnFailureListener { createException ->
                            if (createException is com.google.firebase.auth.FirebaseAuthUserCollisionException ||
                                    createException.localizedMessage?.contains("email already in use", ignoreCase = true) == true) {
                                // Account exists, so the password was wrong
                                onFailure("Incorrect password. Please try again.")
                            } else {
                                onFailure(createException.localizedMessage ?: "Authentication failed")
                            }
                        }
                } else {
                    onFailure(exception.localizedMessage ?: "Login failed")
                }
            }
    }

    fun logout() {
        auth.signOut()
    }

    fun isUserLoggedIn(): Boolean {
        return auth.currentUser != null
    }

    fun getCurrentUserEmail(): String {
        return auth.currentUser?.email ?: ""
    }

    // --- Category Management ---
    fun getCategories(onDataChange: (List<Category>) -> Unit, onError: (String) -> Unit): ValueEventListener {
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val list = mutableListOf<Category>()
                for (child in snapshot.children) {
                    val cat = child.getValue(Category::class.java)
                    if (cat != null) {
                        list.add(cat)
                    }
                }
                onDataChange(list)
            }

            override fun onCancelled(error: DatabaseError) {
                onError(error.message)
            }
        }
        database.getReference("categories").addValueEventListener(listener)
        return listener
    }

    fun addCategory(category: Category, onSuccess: () -> Unit, onFailure: (String) -> Unit) {
        val id = database.getReference("categories").push().key ?: UUID.randomUUID().toString()
        val newCategory = category.copy(id = id)
        database.getReference("categories").child(id).setValue(newCategory)
            .addOnSuccessListener { onSuccess() }
            .addOnFailureListener { e -> onFailure(e.localizedMessage ?: "Failed to add category") }
    }

    fun updateCategory(category: Category, onSuccess: () -> Unit, onFailure: (String) -> Unit) {
        if (category.id.isEmpty()) {
            onFailure("Category ID cannot be empty")
            return
        }
        database.getReference("categories").child(category.id).setValue(category)
            .addOnSuccessListener { onSuccess() }
            .addOnFailureListener { e -> onFailure(e.localizedMessage ?: "Failed to update category") }
    }

    fun deleteCategory(categoryId: String, onSuccess: () -> Unit, onFailure: (String) -> Unit) {
        database.getReference("categories").child(categoryId).removeValue()
            .addOnSuccessListener { onSuccess() }
            .addOnFailureListener { e -> onFailure(e.localizedMessage ?: "Failed to delete category") }
    }

    // --- Channel Management ---
    fun getChannels(onDataChange: (List<Channel>) -> Unit, onError: (String) -> Unit): ValueEventListener {
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val list = mutableListOf<Channel>()
                for (child in snapshot.children) {
                    val ch = child.getValue(Channel::class.java)
                    if (ch != null) {
                        list.add(ch)
                    }
                }
                onDataChange(list)
            }

            override fun onCancelled(error: DatabaseError) {
                onError(error.message)
            }
        }
        database.getReference("channels").addValueEventListener(listener)
        return listener
    }

    fun addChannel(channel: Channel, onSuccess: () -> Unit, onFailure: (String) -> Unit) {
        val id = database.getReference("channels").push().key ?: UUID.randomUUID().toString()
        val newChannel = channel.copy(id = id)
        database.getReference("channels").child(id).setValue(newChannel)
            .addOnSuccessListener { onSuccess() }
            .addOnFailureListener { e -> onFailure(e.localizedMessage ?: "Failed to add channel") }
    }

    fun updateChannel(channel: Channel, onSuccess: () -> Unit, onFailure: (String) -> Unit) {
        if (channel.id.isEmpty()) {
            onFailure("Channel ID cannot be empty")
            return
        }
        database.getReference("channels").child(channel.id).setValue(channel)
            .addOnSuccessListener { onSuccess() }
            .addOnFailureListener { e -> onFailure(e.localizedMessage ?: "Failed to update channel") }
    }

    fun deleteChannel(channelId: String, onSuccess: () -> Unit, onFailure: (String) -> Unit) {
        database.getReference("channels").child(channelId).removeValue()
            .addOnSuccessListener { onSuccess() }
            .addOnFailureListener { e -> onFailure(e.localizedMessage ?: "Failed to delete channel") }
    }

    // --- Advertisement Management ---
    fun getAds(onDataChange: (Map<String, Ad>) -> Unit, onError: (String) -> Unit): ValueEventListener {
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val adsMap = mutableMapOf<String, Ad>()
                // click ad
                val clickSnap = snapshot.child("click")
                val clickAd = clickSnap.getValue(Ad::class.java) ?: Ad("click", "", false)
                adsMap["click"] = clickAd

                // exit ad
                val exitSnap = snapshot.child("exit")
                val exitAd = exitSnap.getValue(Ad::class.java) ?: Ad("exit", "", false)
                adsMap["exit"] = exitAd

                onDataChange(adsMap)
            }

            override fun onCancelled(error: DatabaseError) {
                onError(error.message)
            }
        }
        database.getReference("admin_ads").addValueEventListener(listener)
        return listener
    }

    fun saveAd(ad: Ad, onSuccess: () -> Unit, onFailure: (String) -> Unit) {
        database.getReference("admin_ads").child(ad.id).setValue(ad)
            .addOnSuccessListener {
                // If it is click ad, we sync with original "ads" key for player app compatibility
                if (ad.id == "click") {
                    val adConfigMap = mapOf(
                        "videoAdUrl" to ad.videoUrl,
                        "durationSeconds" to 12 // default duration
                    )
                    database.getReference("ads").setValue(adConfigMap)
                }
                onSuccess()
            }
            .addOnFailureListener { e -> onFailure(e.localizedMessage ?: "Failed to save advertisement") }
    }

    // --- Notice Management ---
    fun getNotices(onDataChange: (List<NoticeItem>) -> Unit, onError: (String) -> Unit): ValueEventListener {
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val list = mutableListOf<NoticeItem>()
                for (child in snapshot.children) {
                    val notice = child.getValue(NoticeItem::class.java)
                    if (notice != null) {
                        list.add(notice)
                    }
                }
                onDataChange(list)
            }

            override fun onCancelled(error: DatabaseError) {
                onError(error.message)
            }
        }
        database.getReference("notice_list").addValueEventListener(listener)
        return listener
    }

    fun addNotice(notice: NoticeItem, onSuccess: () -> Unit, onFailure: (String) -> Unit) {
        val id = database.getReference("notice_list").push().key ?: UUID.randomUUID().toString()
        val newNotice = notice.copy(id = id)
        database.getReference("notice_list").child(id).setValue(newNotice)
            .addOnSuccessListener {
                syncActiveNoticeToPlayerApp()
                onSuccess()
            }
            .addOnFailureListener { e -> onFailure(e.localizedMessage ?: "Failed to add notice") }
    }

    fun updateNotice(notice: NoticeItem, onSuccess: () -> Unit, onFailure: (String) -> Unit) {
        if (notice.id.isEmpty()) {
            onFailure("Notice ID cannot be empty")
            return
        }
        database.getReference("notice_list").child(notice.id).setValue(notice)
            .addOnSuccessListener {
                syncActiveNoticeToPlayerApp()
                onSuccess()
            }
            .addOnFailureListener { e -> onFailure(e.localizedMessage ?: "Failed to update notice") }
    }

    fun deleteNotice(noticeId: String, onSuccess: () -> Unit, onFailure: (String) -> Unit) {
        database.getReference("notice_list").child(noticeId).removeValue()
            .addOnSuccessListener {
                syncActiveNoticeToPlayerApp()
                onSuccess()
            }
            .addOnFailureListener { e -> onFailure(e.localizedMessage ?: "Failed to delete notice") }
    }

    private fun syncActiveNoticeToPlayerApp() {
        // Sync the latest active notice to the "notices" endpoint for player app compatibility
        database.getReference("notice_list").get().addOnSuccessListener { snapshot ->
            var activeNotice: NoticeItem? = null
            for (child in snapshot.children) {
                val item = child.getValue(NoticeItem::class.java)
                if (item != null && item.active) {
                    activeNotice = item
                    break // use the first active one
                }
            }
            if (activeNotice != null) {
                val playerNotice = mapOf(
                    "text" to activeNotice.text,
                    "active" to activeNotice.active
                )
                database.getReference("notices").setValue(playerNotice)
            } else {
                database.getReference("notices").removeValue()
            }
        }
    }

    // --- Settings Management ---
    fun getSettings(onDataChange: (AppSettings) -> Unit, onError: (String) -> Unit): ValueEventListener {
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val settings = snapshot.getValue(AppSettings::class.java) ?: AppSettings()
                onDataChange(settings)
            }

            override fun onCancelled(error: DatabaseError) {
                onError(error.message)
            }
        }
        database.getReference("app_settings").addValueEventListener(listener)
        return listener
    }

    fun saveSettings(settings: AppSettings, onSuccess: () -> Unit, onFailure: (String) -> Unit) {
        database.getReference("app_settings").setValue(settings)
            .addOnSuccessListener { onSuccess() }
            .addOnFailureListener { e -> onFailure(e.localizedMessage ?: "Failed to save settings") }
    }

    // --- Firebase Storage Upload ---
    fun uploadFile(
        uri: Uri,
        folderName: String,
        fileName: String,
        onProgress: (Double) -> Unit,
        onSuccess: (String) -> Unit,
        onFailure: (String) -> Unit
    ) {
        try {
            val contentResolver = context.contentResolver
            val inputStream: InputStream? = contentResolver.openInputStream(uri)
            if (inputStream == null) {
                onFailure("Could not open input stream for selected file.")
                return
            }
            val bytes = inputStream.readBytes()
            inputStream.close()

            val storageRef = storage.reference.child("uploads/$folderName/${UUID.randomUUID()}_$fileName")
            val uploadTask = storageRef.putBytes(bytes)

            uploadTask.addOnProgressListener { taskSnapshot ->
                val progress = (100.0 * taskSnapshot.bytesTransferred / taskSnapshot.totalByteCount)
                onProgress(progress)
            }.addOnSuccessListener {
                storageRef.downloadUrl.addOnSuccessListener { downloadUri ->
                    onSuccess(downloadUri.toString())
                }.addOnFailureListener { e ->
                    onFailure("Failed to get download URL: ${e.localizedMessage}")
                }
            }.addOnFailureListener { e ->
                onFailure("Upload failed: ${e.localizedMessage}")
            }
        } catch (e: Exception) {
            onFailure("Error preparing file for upload: ${e.localizedMessage}")
        }
    }

    // Unsubscribe listeners safely
    fun removeListener(listener: ValueEventListener) {
        database.getReference("categories").removeEventListener(listener)
        database.getReference("channels").removeEventListener(listener)
        database.getReference("admin_ads").removeEventListener(listener)
        database.getReference("notice_list").removeEventListener(listener)
        database.getReference("app_settings").removeEventListener(listener)
    }
}

// Notice Item for Notice List Support
data class NoticeItem(
    val id: String = "",
    val text: String = "",
    val active: Boolean = true
)

// Active or Inactive Channel Model with active state
data class AdminChannel(
    val id: String = "",
    val name: String = "",
    val logoUrl: String = "",
    val streamUrl: String = "",
    val category: String = "",
    val active: Boolean = true
)

// Model for Ads
data class Ad(
    val id: String = "",
    val videoUrl: String = "",
    val enabled: Boolean = false
)

// Model for App Settings
data class AppSettings(
    val appName: String = "IMU TV",
    val footerText: String = "Powered by MD Imam Hossain",
    val telegramLink: String = "https://t.me/imustvsports",
    val telegramPopupEnabled: Boolean = true,
    val shareLink: String = "https://play.google.com/store/apps/details?id=com.example",
    val privacyPolicy: String = "Privacy Policy content here",
    val termsConditions: String = "Terms and Conditions content here",
    val appLogoUrl: String = ""
)
