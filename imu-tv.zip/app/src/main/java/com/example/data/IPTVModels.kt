package com.example.data

data class Channel(
    val id: String = "",
    val name: String = "",
    val logoUrl: String = "",
    val streamUrl: String = "",
    val category: String = "",
    val active: Boolean = true
)

data class Category(
    val id: String = "",
    val name: String = ""
)

data class Notice(
    val text: String = "",
    val active: Boolean = true
)

data class AdConfig(
    val videoAdUrl: String = "",
    val durationSeconds: Int = 12
)
